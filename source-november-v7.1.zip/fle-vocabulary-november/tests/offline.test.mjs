import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {runInNewContext} from 'node:vm';

function worker() {
 const handlers={},stores=new Map();let skipped=0,claimed=0;
 const scope='https://example.test/fle-vocab-cloze/';
 const cache={async addAll(requests){for(const request of requests)stores.set(request.url,new Response('offline page'));},async put(key,value){stores.set(key,value);},async match(key){return stores.get(key)?.clone();}};
 const deleted=[];
 const context={URL,Request,Response,Promise,self:{registration:{scope},addEventListener:(name,fn)=>handlers[name]=fn,skipWaiting:()=>skipped++,clients:{claim:async()=>claimed++}},caches:{open:async()=>cache,keys:async()=>['other-app','fle-vocab-pwa-older'],delete:async name=>{deleted.push(name);return true;}},fetch:async()=>new Response('online page')};
 runInNewContext(readFileSync(new URL('../public/sw.js',import.meta.url),'utf8'),context);
 async function lifecycle(name,data){let completion;handlers[name]({data,waitUntil:promise=>completion=promise});await completion;}
 async function request(url,mode='navigate',method='GET'){let response;handlers.fetch({request:{url,mode,method},respondWith:promise=>response=promise});return response?await response:undefined;}
 return {context,stores,scope,deleted,lifecycle,request,get skipped(){return skipped;},get claimed(){return claimed;}};
}

test('installation precaches the GitHub project path and waits for an explicit update request',async()=>{
 const app=worker();await app.lifecycle('install');
 assert.equal(app.skipped,0);assert(app.stores.has(app.scope));assert(app.stores.has(app.scope+'manifest.webmanifest'));
 assert(!app.stores.has('https://example.test/'));
 await app.lifecycle('message',{type:'SKIP_WAITING'});assert.equal(app.skipped,1);
});

test('navigation refreshes online content and returns that content after losing the network',async()=>{
 const app=worker();await app.lifecycle('install');
 const online=await app.request(app.scope+'?v=7.1');assert.equal(await online.text(),'online page');
 app.context.fetch=async()=>{throw new Error('offline');};
 const offline=await app.request(app.scope+'index.html?again=1');assert.equal(await offline.text(),'online page');
});

test('a server error uses the saved page and unrelated requests are not intercepted',async()=>{
 const app=worker();await app.lifecycle('install');app.context.fetch=async()=>new Response('failure',{status:503});
 assert.equal(await (await app.request(app.scope)).text(),'offline page');
 assert.equal(await app.request('https://other.test/page'),undefined);
 assert.equal(await app.request(app.scope,'navigate','POST'),undefined);
 assert.equal(await app.request(app.scope+'unrelated.json','cors'),undefined);
});

test('activation removes only this application’s older caches',async()=>{
 const app=worker();await app.lifecycle('activate');assert.deepEqual(app.deleted,['fle-vocab-pwa-older']);assert.equal(app.claimed,1);
});
