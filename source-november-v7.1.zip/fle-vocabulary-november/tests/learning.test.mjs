import test from 'node:test';
import assert from 'node:assert/strict';
import {NOVEMBER,ALL_WORDS,BY_ID,wordsFor,EXPORT_WORDS,isCorrectForm} from '../src/data.ts';
import {createRound,evaluateRound,restoreRound,todayPlan,status,sanitizeMistakes,chooseQuestion,assignChoice} from '../src/engine.ts';
import {DAY,scheduleReview,sanitizeReviewState,beijingDateKey} from '../src/review-schedule.ts';
import {readFile} from 'node:fs/promises';
const now=Date.parse('2026-11-06T14:00:00+08:00');
const word=id=>BY_ID.get('nov-'+id);
const correct=round=>({...round,answers:Object.fromEntries(round.questionIds.map(id=>[id,id])),formValues:Object.fromEntries(round.questionIds.map(id=>[id,BY_ID.get(id).questions[round.exampleIndexes[id]].answer]))});

test('the November source contains exactly five lists of 15 words and ten usable questions per word',()=>{
 assert.equal(NOVEMBER.length,75);assert.equal(new Set(NOVEMBER.map(w=>w.id)).size,75);
 for(const list of [7,8,9,10,11])assert.equal(NOVEMBER.filter(w=>w.list===list).length,15);
 assert.equal(NOVEMBER.reduce((n,w)=>n+w.questions.length,0),750);
 for(const w of NOVEMBER){assert.equal(w.questions.length,10,w.word);assert.ok(w.sourceDefinition.trim().length>2,w.word);assert.equal(new Set(w.questions.map(q=>q.text)).size,10,w.word);
  for(const q of w.questions){assert.equal((q.text.match(/____/g)??[]).length,1,w.word);assert.ok(w.forms.includes(q.answer),w.word+':'+q.answer);assert.ok(q.assistance.length>10);assert.ok(!/^(Rare\.|Say |Keep the order)/.test(q.text),q.text);}
 }
 assert.equal(EXPORT_WORDS.split('\n').length,75);assert.ok(EXPORT_WORDS.includes('eye up\n'));assert.ok(EXPORT_WORDS.includes('gape at\n'));assert.ok(EXPORT_WORDS.includes('hammer and tongs\n'));
 assert.equal(EXPORT_WORDS.split('\n').filter(w=>w.includes(' ')).length,3);
});
test('the deployed October word bank and stable question indexes survive the November update',async()=>{
 const old=JSON.parse(await readFile(new URL('../src/legacy-data.json',import.meta.url),'utf8')).words;
 assert.equal(wordsFor('october').length,45);
 for(const original of old){const current=BY_ID.get(original.id);assert.deepEqual(current.examples,original.examples);assert.equal(current.questions.length,original.examples.length);}
 const draft={kind:'free',questionIds:['strand','compose-yourself'],choiceIds:['strand','compose-yourself','spurt','ooze'],exampleIndexes:{strand:9,'compose-yourself':4},answers:{strand:'strand'},hints:['strand'],position:1,createdAt:now};
 const restored=restoreRound(draft);assert.equal(restored.period,'october');assert.equal(restored.formValues.strand,'strand');assert.equal(restored.exampleIndexes.strand,9);assert.equal(restored.position,1);
 const record=scheduleReview(undefined,now,'correct').record;
 const clean=sanitizeReviewState({strand:record,'nov-chime':record},new Set(ALL_WORDS.map(w=>w.id)));assert.equal(Object.keys(clean).length,2);
});
test('each variable family has multiple tested forms; fixed phrases and invariant words stay intact',()=>{
 const fixed=new Set(['paltry','headlong','gamely','hammer and tongs','slew']);
 for(const w of NOVEMBER){const forms=new Set(w.questions.map(q=>q.answer));if(fixed.has(w.word))assert.ok(forms.has(w.word));else assert.ok(forms.size>=2,w.word);}
 assert.ok(word('eye-up').questions.every(q=>q.answer.endsWith(' up')));
 assert.ok(word('gape-at').questions.every(q=>q.answer.endsWith(' at')));
 assert.ok(word('hammer-and-tongs').questions.every(q=>q.answer==='hammer and tongs'));
});
test('legitimate English spelling variants, whitespace and capitals are accepted without accepting the wrong tense',()=>{
 const q=(id,answer)=>word(id).questions.find(q=>q.answer===answer);
 assert.ok(isCorrectForm(q('spiral','spiralled'),'Spiraled'));
 assert.ok(isCorrectForm(q('spiral','spiralling'),'spiraling'));
 assert.ok(isCorrectForm(q('tantalise','tantalising'),'tantalizing'));
 assert.ok(isCorrectForm(q('disorientating','disorientating'),'disorienting'));
 assert.ok(isCorrectForm(q('eye-up','eyeing up'),' EYEING   UP '));
 assert.ok(isCorrectForm(q('bust','busted'),'bust'));
 assert.ok(!isCorrectForm(q('propel','propelled'),'propel'));
 assert.ok(!isCorrectForm(q('carcass','carcasses'),'carcass'));
 assert.ok(!isCorrectForm(q('gape-at','gaped at'),'gaped'));
});
test('mixed sessions reach base and changed forms without repeating the previous context',()=>{
 const words=NOVEMBER.slice(0,15),round=createRound('new',words.map(w=>w.id),NOVEMBER,now,'november',{}, {},()=>.45);
 const changed=round.questionIds.map(id=>BY_ID.get(id).questions[round.exampleIndexes[id]].answer!==BY_ID.get(id).word);
 assert.ok(changed.some(Boolean));assert.ok(changed.some(v=>!v));assert.notDeepEqual(round.choiceIds,round.questionIds);
 for(const w of NOVEMBER){for(let previous=0;previous<10;previous++){const index=chooseQuestion(w,true,[previous],previous,()=>.01);assert.notEqual(index,previous,w.word);}}
});
test('an empty answer cannot be submitted and one word family cannot be used twice',()=>{
 const r=createRound('free',NOVEMBER.slice(0,3).map(w=>w.id),NOVEMBER,now,'november');assert.equal(evaluateRound(r,{}, {},{},now),null);
 const filled=correct(r);filled.answers[filled.questionIds[1]]=filled.answers[filled.questionIds[0]];assert.equal(evaluateRound(filled,{}, {},{},now),null);
});
test('a right family with a wrong form is a form mistake, does not earn mastery, and retains the submitted form',()=>{
 const w=word('propel'),index=w.questions.findIndex(q=>q.answer==='propelled');const r=createRound('new',[w.id],NOVEMBER,now,'november');r.exampleIndexes[w.id]=index;const filled=correct(r);filled.formValues[w.id]='propel';
 const out=evaluateRound(filled,{}, {},{},now);assert.equal(out.report.results[0].reason,'form');assert.equal(out.report.results[0].wordCorrect,true);assert.equal(out.records[w.id].level,0);assert.equal(out.mistakes[w.id].lastInput,'propel');assert.equal(out.mistakes[w.id].expected,'propelled');
 assert.equal(sanitizeMistakes(out.mistakes)[w.id].reason,'form');
});
test('word mistakes and hints remain distinct from form mistakes',()=>{
 const r=createRound('new',['nov-chime'],NOVEMBER,now,'november'),filled=correct(r);const wrong=r.choiceIds.find(id=>id!=='nov-chime');filled.answers['nov-chime']=wrong;filled.formValues['nov-chime']=BY_ID.get(wrong).word;
 const out=evaluateRound(filled,{}, {},{},now);assert.equal(out.report.results[0].reason,'word');
 const helped=correct(r);helped.hints=['nov-chime'];const assisted=evaluateRound(helped,{}, {},{},now);assert.equal(assisted.report.results[0].reason,'hint');assert.equal(assisted.records['nov-chime'].level,0);
});
test('free practice changes neither schedules nor daily quotas, while saving form mistakes and question history',()=>{
 const id='nov-propel',record=scheduleReview(undefined,now-DAY,'correct').record,records={[id]:record};const before=todayPlan(NOVEMBER,records,now);const r=createRound('free',[id],NOVEMBER,now,'november');r.exampleIndexes[id]=word('propel').questions.findIndex(q=>q.answer==='propelled');const filled=correct(r);filled.formValues[id]='propeling';const out=evaluateRound(filled,records,{}, {},now);
 assert.deepEqual(out.records,records);assert.deepEqual(todayPlan(NOVEMBER,out.records,now),before);assert.equal(out.mistakes[id].reason,'form');assert.equal(out.history[id].length,1);
});
test('mistake review changes context; same-day success waits, cross-day independent success closes the loop',()=>{
 const id='nov-dab',r=createRound('new',[id],NOVEMBER,now,'november');r.exampleIndexes[id]=word('dab').questions.findIndex(q=>q.answer==='dabbed');const wrong=correct(r);wrong.formValues[id]='dab';const first=evaluateRound(wrong,{}, {},{},now);
 const review=createRound('mistakes',[id],NOVEMBER,now+1000,'november',first.history,first.mistakes);assert.notEqual(review.exampleIndexes[id],r.exampleIndexes[id]);assert.ok(review.choiceIds.length>=4);
 const today=evaluateRound(correct(review),first.records,first.mistakes,first.history,now+1000);assert.equal(status(today.mistakes[id],now+1000),'waiting');
 const tomorrowRound=createRound('mistakes',[id],NOVEMBER,now+DAY,'november',today.history,today.mistakes);const tomorrow=evaluateRound(correct(tomorrowRound),today.records,today.mistakes,today.history,now+DAY);assert.equal(tomorrow.mistakes[id].resolved,true);
});
test('November plans ignore October counters, while a pending mistake keeps the day open',()=>{
 const old=scheduleReview(undefined,now,'correct').record;const plan=todayPlan(NOVEMBER,{strand:old},now);assert.equal(plan.tested,0);assert.equal(plan.freshIds.length,15);
 const r=createRound('new',plan.freshIds,NOVEMBER,now,'november');const out=evaluateRound(correct(r),{}, {},{},now);assert.equal(todayPlan(NOVEMBER,out.records,now,out.mistakes).complete,true);
 const id=r.questionIds[0];const m={[id]:{lastMissAt:now,confusedWith:[],resolved:false}};assert.equal(todayPlan(NOVEMBER,out.records,now,m).complete,false);
});
test('draft restoration preserves edited forms, spacing, hints and independent question order',()=>{
 const r=createRound('free',NOVEMBER.slice(0,4).map(w=>w.id),NOVEMBER,now,'november');const filled=correct(r);filled.position=2;filled.hints=[filled.questionIds[1]];filled.formValues[filled.questionIds[0]]=' Typed   FORM ';
 assert.deepEqual(restoreRound(JSON.parse(JSON.stringify(filled))),filled);
 assert.equal(restoreRound({...filled,questionIds:['unknown']}),null);
});
test('re-tapping a selected family preserves the edited form, and tapping a used family goes back to its question',()=>{
 const original=createRound('free',['nov-propel','nov-hiss'],NOVEMBER,now,'november');
 const first=assignChoice(original,'nov-propel');const id=first.questionIds[first.position];
 first.formValues[id]='propelled';
 assert.equal(assignChoice(first,'nov-propel'),first);
 assert.equal(assignChoice(first,'nov-propel').formValues[id],'propelled');
 const other={...first,position:1};const returned=assignChoice(other,'nov-propel');
 assert.equal(returned.position,first.position);assert.equal(returned.formValues[id],'propelled');
 const changed=assignChoice(first,'nov-hiss');assert.equal(changed.formValues[id],'hiss');
 assert.equal(first.formValues[id],'propelled');
});
test('Beijing date boundaries and D+1, D+3, D+7 still follow the established review schedule',()=>{
 const start=Date.parse('2026-11-06T23:55:00+08:00');const a=scheduleReview(undefined,start,'correct').record;assert.notEqual(beijingDateKey(a.dueAt),beijingDateKey(start));const b=scheduleReview(a,a.dueAt+1000,'correct').record;assert.equal(b.level,2);assert.equal(beijingDateKey(b.dueAt)-beijingDateKey(b.lastSeenAt),'3'-0);const c=scheduleReview(b,b.dueAt+1000,'correct').record;assert.equal(c.level,3);assert.equal(Number(beijingDateKey(c.dueAt))-Number(beijingDateKey(c.lastSeenAt)),7);
});
