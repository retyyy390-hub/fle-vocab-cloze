import {defineConfig} from 'vite';
import react from '@vitejs/plugin-react';
export default defineConfig({base:'./',plugins:[react()],build:{cssCodeSplit:false,assetsInlineLimit:1000000,rollupOptions:{output:{inlineDynamicImports:true}}}});
