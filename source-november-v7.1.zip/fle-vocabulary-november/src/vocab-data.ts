import { EXTRA_EXAMPLES } from "./vocab-extra";
import { VOCAB_PARAPHRASES } from "./vocab-paraphrases";
import { LIST6 } from "./vocab-list6";

export type VocabItem = {
  id: string;
  word: string;
  answers?: string[];
  list: number;
  pos: string;
  meaning: string;
  examples: string[];
  paraphrases: string[];
};

type BaseVocabItem = Omit<VocabItem, "paraphrases">;

const BASE_VOCAB: BaseVocabItem[] = [
  {
    id: "gist",
    word: "gist",
    list: 1,
    pos: "noun",
    meaning: "the general or main meaning of a text or statement",
    examples: [
      "I missed some details, but I understood the ____ of her argument.",
      "Read the opening paragraph quickly to get the ____ of the article.",
    ],
  },
  {
    id: "annotate",
    word: "annotate",
    list: 1,
    pos: "verb",
    meaning: "to add short explanations or comments to a text or image",
    examples: [
      "Please ____ the passage with notes about tone and imagery.",
      "Students were asked to ____ the diagram before answering the questions.",
    ],
  },
  {
    id: "hoist",
    word: "hoist",
    list: 1,
    pos: "verb",
    meaning: "to lift something heavy, often using ropes or machinery",
    examples: [
      "The crew used a crane to ____ the equipment onto the roof.",
      "Together, the sailors managed to ____ the heavy sail into position.",
    ],
  },
  {
    id: "criss-cross",
    word: "criss-cross",
    answers: ["crisscross"],
    list: 1,
    pos: "verb",
    meaning: "to form or move in a pattern of crossing lines",
    examples: [
      "Narrow footpaths ____ the hillside in every direction.",
      "Old railway lines ____ the industrial district.",
    ],
  },
  {
    id: "bemoan",
    word: "bemoan",
    list: 1,
    pos: "verb",
    meaning: "to complain about or express sadness over something",
    examples: [
      "Residents continue to ____ the loss of the town's old cinema.",
      "It is easy to ____ your lack of time instead of changing your priorities.",
    ],
  },
  {
    id: "nirvana",
    word: "nirvana",
    list: 1,
    pos: "noun",
    meaning: "a state of complete peace or freedom from suffering; a perfect state",
    examples: [
      "For the exhausted hikers, the quiet cabin felt like ____.",
      "The retreat promised a kind of digital ____ away from constant notifications.",
    ],
  },
  {
    id: "cast-iron",
    word: "cast-iron",
    answers: ["cast iron"],
    list: 1,
    pos: "adjective",
    meaning: "extremely strong, reliable, or certain",
    examples: [
      "The investigators needed a ____ explanation supported by clear evidence.",
      "There is no ____ guarantee that the plan will succeed.",
    ],
  },
  {
    id: "genre",
    word: "genre",
    list: 1,
    pos: "noun",
    meaning: "a particular style or category of art, literature, or music",
    examples: [
      "Science fiction is the literary ____ she reads most often.",
      "The director combined features from more than one film ____.",
    ],
  },
  {
    id: "prickle",
    word: "prickle",
    list: 1,
    pos: "verb",
    meaning: "to cause or experience a slight sharp or tingling sensation",
    examples: [
      "The rough wool made the skin on my neck ____.",
      "A sudden sense of danger made his scalp ____.",
    ],
  },
  {
    id: "fiction",
    word: "fiction",
    list: 1,
    pos: "noun",
    meaning: "writing about imaginary characters and events",
    examples: [
      "Although it feels realistic, the story is a work of ____.",
      "Historical ____ often blends invented characters with real events.",
    ],
  },
  {
    id: "meander",
    word: "meander",
    list: 1,
    pos: "verb",
    meaning: "to follow an indirect route or proceed without clear direction",
    examples: [
      "The river begins to ____ slowly across the flat valley.",
      "Without a clear thesis, the essay may ____ from one idea to another.",
    ],
  },
  {
    id: "enamel",
    word: "enamel",
    list: 1,
    pos: "noun",
    meaning: "a hard, glossy protective coating; also the hard outer layer of a tooth",
    examples: [
      "The old metal bowl was protected by a layer of blue ____.",
      "Sugary drinks can gradually damage tooth ____.",
    ],
  },
  {
    id: "meet",
    word: "meet",
    list: 1,
    pos: "noun",
    meaning: "an organised sports competition",
    examples: [
      "The school will host an athletics ____ on Friday afternoon.",
      "She broke the record at the regional swimming ____.",
    ],
  },
  {
    id: "a-screeching-halt",
    word: "a screeching halt",
    answers: ["screeching halt"],
    list: 1,
    pos: "phrase",
    meaning: "a sudden and unexpected end to movement or activity",
    examples: [
      "The construction project came to ____ when its funding disappeared.",
      "Traffic came to ____ after the accident blocked both lanes.",
    ],
  },
  {
    id: "nuance",
    word: "nuance",
    list: 1,
    pos: "noun",
    meaning: "a subtle difference in meaning, expression, or feeling",
    examples: [
      "A good translation preserves every ____ of the original argument.",
      "Her performance captured the emotional ____ of the character.",
    ],
  },
  {
    id: "eerie",
    word: "eerie",
    list: 2,
    pos: "adjective",
    meaning: "strange in a frightening and mysterious way",
    examples: [
      "An ____ silence settled over the abandoned station.",
      "The empty playground looked ____ in the pale moonlight.",
    ],
  },
  {
    id: "tingle",
    word: "tingle",
    list: 2,
    pos: "verb",
    meaning: "to feel a slight prickling sensation or a sudden strong emotion",
    examples: [
      "The cold wind made my fingertips ____.",
      "Her skin began to ____ with excitement as the results were announced.",
    ],
  },
  {
    id: "trudge",
    word: "trudge",
    list: 2,
    pos: "verb",
    meaning: "to walk slowly with heavy steps because of effort or tiredness",
    examples: [
      "After the long match, we had to ____ back up the hill.",
      "The hikers continued to ____ through the deep mud.",
    ],
  },
  {
    id: "parch",
    word: "parch",
    list: 2,
    pos: "verb",
    meaning: "to make something extremely dry or make someone very thirsty",
    examples: [
      "Weeks without rain began to ____ the surrounding fields.",
      "The dry desert air seemed to ____ his throat.",
    ],
  },
  {
    id: "lurking",
    word: "lurking",
    list: 2,
    pos: "adjective",
    meaning: "hidden and waiting, often in a threatening or harmful way",
    examples: [
      "The report exposed a ____ danger beneath the calm surface.",
      "She had the uneasy sense that a problem was ____ nearby.",
    ],
  },
  {
    id: "wobble",
    word: "wobble",
    list: 2,
    pos: "verb",
    meaning: "to move unsteadily from side to side or become uncertain",
    examples: [
      "The table began to ____ whenever anyone touched it.",
      "His confidence started to ____ under close questioning.",
    ],
  },
  {
    id: "pellet",
    word: "pellet",
    list: 2,
    pos: "noun",
    meaning: "a small, rounded, compressed piece of a substance",
    examples: [
      "Each food ____ contained a measured amount of grain.",
      "The machine compressed the material into a small ____.",
    ],
  },
  {
    id: "pounding",
    word: "pounding",
    list: 2,
    pos: "noun",
    meaning: "repeated heavy beats or a strong throbbing sensation",
    examples: [
      "A sudden ____ on the front door woke the entire house.",
      "She could feel the rapid ____ of her heart before the race.",
    ],
  },
  {
    id: "sheaf",
    word: "sheaf",
    list: 2,
    pos: "noun",
    meaning: "a tied bundle of grain stalks or a collection of papers",
    examples: [
      "He arrived carrying a thick ____ of handwritten notes.",
      "The farmer tied the cut wheat into a neat ____.",
    ],
  },
  {
    id: "inexplicable",
    word: "inexplicable",
    list: 2,
    pos: "adjective",
    meaning: "impossible to explain or understand logically",
    examples: [
      "For some ____ reason, every clock in the building had stopped.",
      "The data showed an ____ drop that required further investigation.",
    ],
  },
  {
    id: "recast",
    word: "recast",
    list: 2,
    pos: "verb",
    meaning: "to change the form, structure, or presentation of something",
    examples: [
      "The editor decided to ____ the article as a personal narrative.",
      "We can ____ the problem as an opportunity to redesign the system.",
    ],
  },
  {
    id: "exacting",
    word: "exacting",
    list: 2,
    pos: "adjective",
    meaning: "demanding great care, effort, and precision",
    examples: [
      "Restoring the damaged painting was slow and ____ work.",
      "The laboratory follows ____ standards of accuracy.",
    ],
  },
  {
    id: "laden",
    word: "laden",
    list: 2,
    pos: "adjective",
    meaning: "heavily loaded or filled with a particular quality",
    examples: [
      "The branches were ____ with wet snow.",
      "His speech was ____ with references that few listeners understood.",
    ],
  },
  {
    id: "wreak",
    word: "wreak",
    list: 2,
    pos: "verb",
    meaning: "to cause serious damage, harm, or destruction",
    examples: [
      "The powerful storm could ____ havoc across the coastline.",
      "A single false rumour can ____ enormous damage online.",
    ],
  },
  {
    id: "devastation",
    word: "devastation",
    list: 2,
    pos: "noun",
    meaning: "widespread and severe destruction or damage",
    examples: [
      "Photographs revealed the ____ left by the flood.",
      "Years later, the forest still showed signs of the fire's ____.",
    ],
  },
  {
    id: "loom",
    word: "loom",
    list: 3,
    pos: "verb",
    meaning: "to appear as a large, unclear, and often threatening shape",
    examples: [
      "As the mist thickened, a dark tower began to ____ ahead of us.",
      "A huge cliff seemed to ____ above the narrow road.",
    ],
  },
  {
    id: "stifle",
    word: "stifle",
    list: 3,
    pos: "verb",
    meaning: "to prevent, suppress, or make it difficult to breathe",
    examples: [
      "Excessive rules may ____ creativity in the classroom.",
      "He tried to ____ a laugh during the serious announcement.",
    ],
  },
  {
    id: "oppressive",
    word: "oppressive",
    list: 3,
    pos: "adjective",
    meaning: "cruelly controlling, or intensely uncomfortable and suffocating",
    examples: [
      "The room felt ____ in the heavy summer heat.",
      "The novel portrays life under an ____ regime.",
    ],
  },
  {
    id: "bicker",
    word: "bicker",
    list: 3,
    pos: "verb",
    meaning: "to argue repeatedly about unimportant things",
    examples: [
      "The siblings continued to ____ over who should sit by the window.",
      "Team members began to ____ about minor details instead of solving the problem.",
    ],
  },
  {
    id: "tatty",
    word: "tatty",
    list: 3,
    pos: "adjective",
    meaning: "worn, damaged, or in poor condition through heavy use",
    examples: [
      "He pulled a ____ notebook from the bottom of his bag.",
      "The once elegant curtains now looked faded and ____.",
    ],
  },
  {
    id: "seamless",
    word: "seamless",
    list: 3,
    pos: "adjective",
    meaning: "smooth and continuous, without awkward breaks or transitions",
    examples: [
      "The new system should provide a ____ transition between lessons.",
      "Her editing created a ____ flow from one scene to the next.",
    ],
  },
  {
    id: "luxuriate",
    word: "luxuriate",
    list: 3,
    pos: "verb",
    meaning: "to take great pleasure in something comfortable or enjoyable",
    examples: [
      "After the cold walk, we could ____ in the warmth of the café.",
      "She allowed herself to ____ in the rare silence of the empty house.",
    ],
  },
  {
    id: "mill-about",
    word: "mill about",
    answers: ["mill around"],
    list: 3,
    pos: "phrasal verb",
    meaning: "to move around without a clear purpose, often in a confused group",
    examples: [
      "Visitors continued to ____ near the entrance while they waited.",
      "With no instructions, the students began to ____ in the corridor.",
    ],
  },
  {
    id: "flank",
    word: "flank",
    list: 3,
    pos: "verb",
    meaning: "to be positioned on the side of someone or something",
    examples: [
      "Rows of tall trees ____ the road on both sides.",
      "Two stone towers ____ the main entrance to the castle.",
    ],
  },
  {
    id: "scramble",
    word: "scramble",
    list: 3,
    pos: "verb",
    meaning: "to climb or move quickly with difficulty, or compete urgently",
    examples: [
      "We had to ____ over the loose rocks to reach the ridge.",
      "Reporters began to ____ for the limited seats in the hall.",
    ],
  },
  {
    id: "obscure",
    word: "obscure",
    list: 3,
    pos: "verb / adjective",
    meaning: "to make unclear, or to be little known and difficult to understand",
    examples: [
      "Low clouds began to ____ the top of the mountain.",
      "The writer's ____ references confused most readers.",
    ],
  },
  {
    id: "teeter",
    word: "teeter",
    list: 3,
    pos: "verb",
    meaning: "to stand unsteadily or be close to a dangerous change",
    examples: [
      "The stack of books began to ____ on the edge of the desk.",
      "For several weeks, the project seemed to ____ on the brink of failure.",
    ],
  },
  {
    id: "recede",
    word: "recede",
    list: 3,
    pos: "verb",
    meaning: "to move back, become more distant, or gradually grow weaker",
    examples: [
      "As the boat moved away, the shoreline began to ____.",
      "The noise slowly started to ____ into the distance.",
    ],
  },
  {
    id: "heave",
    word: "heave",
    list: 3,
    pos: "verb",
    meaning: "to lift, pull, or throw something heavy with great effort",
    examples: [
      "They had to ____ the soaked bag onto the platform.",
      "With one final effort, the workers managed to ____ the door open.",
    ],
  },
  {
    id: "sodden",
    word: "sodden",
    list: 3,
    pos: "adjective",
    meaning: "extremely wet, heavy, and soaked through",
    examples: [
      "After hours of rain, our clothes were completely ____.",
      "The gardener lifted a pile of ____ leaves from the path.",
    ],
  },
  {
    id: "strand",
    word: "strand",
    list: 4,
    pos: "noun / verb",
    meaning: "a single thin piece or one part of a story; to leave someone unable to leave a place",
    examples: [
      "A single ____ of hair lay across the page.",
      "A mechanical failure could ____ the hikers far from the village.",
    ],
  },
  {
    id: "synthesise",
    word: "synthesise",
    list: 4,
    pos: "verb",
    meaning: "to combine separate ideas or parts into one coherent whole",
    examples: [
      "A strong conclusion should ____ evidence from across the passage.",
      "The report must ____ several sources rather than summarise them separately.",
    ],
  },
  {
    id: "rugged",
    word: "rugged",
    list: 4,
    pos: "adjective",
    meaning: "rough, uneven, rocky, and difficult to cross; a face with strong, rough features",
    examples: [
      "Only experienced walkers attempted the ____ mountain route.",
      "The vehicle was designed for ____ terrain.",
    ],
  },
  {
    id: "spurt",
    word: "spurt",
    list: 4,
    pos: "verb / noun",
    meaning: "to flow out forcefully or increase quickly for a short period",
    examples: [
      "Water began to ____ from a crack in the pipe.",
      "The company experienced a brief growth ____ at the end of the year.",
    ],
  },
  {
    id: "curb",
    word: "curb",
    list: 4,
    pos: "verb / noun",
    meaning: "to control or limit something; a restraint; the raised edge between a road and pavement",
    examples: [
      "The new policy aims to ____ unnecessary waste.",
      "She struggled to ____ her impatience during the long delay.",
    ],
  },
  {
    id: "trafficking",
    word: "trafficking",
    list: 4,
    pos: "noun",
    meaning: "the illegal trade or movement of goods or people",
    examples: [
      "The investigation focused on the illegal ____ of protected wildlife.",
      "International cooperation is needed to prevent human ____.",
    ],
  },
  {
    id: "snare",
    word: "snare",
    list: 4,
    pos: "noun / verb",
    meaning: "a trap, or to catch someone or something in a trap",
    examples: [
      "The ranger removed an illegal ____ from the forest.",
      "The misleading offer was designed to ____ careless customers.",
    ],
  },
  {
    id: "swerve",
    word: "swerve",
    list: 4,
    pos: "verb / noun",
    meaning: "to change direction suddenly, or a sudden change of direction",
    examples: [
      "The cyclist had to ____ to avoid a fallen branch.",
      "The driver was forced to ____ sharply away from the obstruction.",
    ],
  },
  {
    id: "glitz",
    word: "glitz",
    list: 4,
    pos: "noun",
    meaning: "showy glamour that is bright and exciting but often superficial",
    examples: [
      "Behind the ____ of the awards ceremony was months of careful work.",
      "The campaign relied on celebrity ____ rather than a convincing message.",
    ],
  },
  {
    id: "ostentation",
    word: "ostentation",
    list: 4,
    pos: "noun",
    meaning: "an excessive display intended to impress others",
    examples: [
      "The simple room was designed without luxury or ____.",
      "His quiet generosity contrasted with the ____ of the public event.",
    ],
  },
  {
    id: "reap",
    word: "reap",
    list: 4,
    pos: "verb",
    meaning: "to collect a crop or receive a result from earlier actions",
    examples: [
      "Students who practise consistently will ____ the benefits later.",
      "The farmers were ready to ____ the wheat at the end of summer.",
    ],
  },
  {
    id: "respiratory",
    word: "respiratory",
    list: 4,
    pos: "adjective",
    meaning: "relating to breathing or the organs used for breathing",
    examples: [
      "Air pollution can contribute to ____ problems.",
      "The athlete was examined for signs of a ____ infection.",
    ],
  },
  {
    id: "incinerator",
    word: "incinerator",
    list: 4,
    pos: "noun",
    meaning: "a device or structure that burns waste at very high temperatures",
    examples: [
      "Non-recyclable waste was transported to the municipal ____.",
      "The hospital uses a specialised ____ for certain waste materials.",
    ],
  },
  {
    id: "shredder",
    word: "shredder",
    list: 4,
    pos: "noun",
    meaning: "a machine that cuts paper or other material into small pieces",
    examples: [
      "Old confidential documents were placed in the ____.",
      "The garden ____ reduced the branches to small chips.",
    ],
  },
  {
    id: "elaborate",
    word: "elaborate",
    list: 4,
    pos: "adjective / verb",
    meaning: "highly detailed and complicated, or to explain in greater detail",
    examples: [
      "The stage was covered by an ____ network of lights and cables.",
      "Could you ____ on the final point in your argument?",
    ],
  },
  {
    id: "nostalgia",
    word: "nostalgia",
    list: 5,
    pos: "noun",
    meaning: "a sentimental and often bittersweet longing for the past",
    examples: [
      "The old photographs filled her with ____ for her childhood.",
      "The exhibition appeals to visitors' ____ for early video games.",
    ],
  },
  {
    id: "wail",
    word: "wail",
    list: 5,
    pos: "verb / noun",
    meaning: "to make a long, high-pitched cry of pain or grief, or the cry itself",
    examples: [
      "The baby began to ____ when the room suddenly went dark.",
      "A distant siren started to ____ across the empty streets.",
    ],
  },
  {
    id: "quadruple",
    word: "quadruple",
    list: 5,
    pos: "verb / adjective",
    meaning: "to become four times larger, or consisting of four times as much",
    examples: [
      "Online orders could ____ during the holiday period.",
      "The upgraded server had ____ the storage capacity of the old one.",
    ],
  },
  {
    id: "daunting",
    word: "daunting",
    list: 5,
    pos: "adjective",
    meaning: "seeming difficult enough to cause fear or loss of confidence",
    examples: [
      "Reading all five lists at once can feel ____.",
      "The climb looked ____ from the bottom of the mountain.",
    ],
  },
  {
    id: "self-contained-bubble",
    word: "self-contained bubble",
    answers: ["self contained bubble"],
    list: 5,
    pos: "phrase",
    meaning: "an isolated environment that has little contact with the outside world",
    examples: [
      "The remote campus sometimes felt like a ____ cut off from the city.",
      "Working only with the same small group created a ____ around the team.",
    ],
  },
  {
    id: "prevalent",
    word: "prevalent",
    list: 5,
    pos: "adjective",
    meaning: "widespread or commonly occurring in a particular place or group",
    examples: [
      "This belief remains ____ among younger readers.",
      "The problem is especially ____ in crowded urban areas.",
    ],
  },
  {
    id: "yank",
    word: "yank",
    list: 5,
    pos: "verb",
    meaning: "to pull something suddenly and sharply",
    examples: [
      "Do not ____ the cable; remove it carefully from the socket.",
      "She had to ____ the stuck drawer open.",
    ],
  },
  {
    id: "smug",
    word: "smug",
    list: 5,
    pos: "adjective",
    meaning: "excessively pleased with yourself in a way that annoys others",
    examples: [
      "His ____ smile disappeared when the final result was announced.",
      "The narrator's ____ tone makes the character difficult to like.",
    ],
  },
  {
    id: "brow",
    word: "brow",
    list: 5,
    pos: "noun",
    meaning: "the forehead or eyebrow ridge; the top edge of a steep hill or slope",
    examples: [
      "She wiped the rain from her ____ and kept walking.",
      "At the ____ of the hill, the entire valley came into view.",
    ],
  },
  {
    id: "sprawl",
    word: "sprawl",
    list: 5,
    pos: "verb / noun",
    meaning: "to spread irregularly over a large area; to sit or lie with arms and legs spread out",
    examples: [
      "New suburbs continue to ____ beyond the old city boundary.",
      "From above, the urban ____ stretched towards the coast.",
    ],
  },
  {
    id: "verdant",
    word: "verdant",
    list: 5,
    pos: "adjective",
    meaning: "green with abundant grass, plants, or other vegetation",
    examples: [
      "Rain had transformed the dry valley into a ____ landscape.",
      "The house stood among ____ fields and thick woodland.",
    ],
  },
  {
    id: "jolt",
    word: "jolt",
    list: 5,
    pos: "verb / noun",
    meaning: "a sudden rough movement or an unexpected emotional shock",
    examples: [
      "The bus gave a sharp ____ as it crossed the uneven road.",
      "The unexpected announcement seemed to ____ everyone into action.",
    ],
  },
  {
    id: "compose-yourself",
    word: "compose yourself",
    list: 5,
    pos: "verb phrase",
    meaning: "to deliberately become calm and regain control of your emotions",
    examples: [
      "Take a moment to ____ before you begin the presentation.",
      "He stepped outside briefly to ____ after the tense meeting.",
    ],
  },
  {
    id: "foreboding",
    word: "foreboding",
    list: 5,
    pos: "noun / adjective",
    meaning: "a strong feeling or sign that something unpleasant may happen",
    examples: [
      "The darkening sky filled the travellers with ____.",
      "A ____ silence hung over the house before the announcement.",
    ],
  },
  {
    id: "bestir",
    word: "bestir",
    list: 5,
    pos: "verb",
    meaning: "to become active or make an effort after being inactive",
    examples: [
      "He finally began to ____ himself and organise the neglected room.",
      "The sleepy village did not ____ itself until well after sunrise.",
    ],
  },
];

export const ALL_VOCAB: VocabItem[] = [...BASE_VOCAB.map((item) => ({
  ...item,
  examples: [...item.examples, ...(EXTRA_EXAMPLES[item.id] ?? [])],
  paraphrases: VOCAB_PARAPHRASES[item.id] ?? [],
})), ...LIST6];

export const ACTIVE_LISTS = [4, 5, 6];
export const VOCAB = ALL_VOCAB.filter((item) => ACTIVE_LISTS.includes(item.list));
