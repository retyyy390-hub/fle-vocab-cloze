export const VOCAB_PARAPHRASES: Record<string, string[]> = {
  "gist": [
    "I did not understand every detail, but I understood the main idea of her argument.",
    "Read the first paragraph quickly to understand the article's main idea.",
    "The summary gives the report's main point without including every detail.",
    "She understood the proposal's main idea without reading every page.",
    "Can you state the main point of his complaint in one sentence?"
  ],
  "annotate": [
    "Please add notes to the passage about its tone and use of images.",
    "Students had to add helpful notes to the diagram before answering the questions.",
    "While reading, add a note to each phrase that shows the narrator's attitude.",
    "Researchers often add labels to photographs to show important features.",
    "Add short notes in the margins of the chapter before class."
  ],
  "hoist": [
    "The crew used a crane to lift the equipment onto the roof.",
    "Working together, the sailors lifted the heavy sail into the correct position.",
    "A pulley helped them lift the crate to the upper floor.",
    "At sunrise, the crew came together to raise the flag.",
    "It took four people to lift the heavy beam into position."
  ],
  "criss-cross": [
    "Narrow paths cross one another all over the hillside.",
    "Old railway lines run across the industrial area in many directions.",
    "Narrow canals cross one another throughout the city's old area.",
    "Thin cracks form crossing lines across the ground after many dry weeks.",
    "Bus routes cross the city centre in many directions and connect all the main areas."
  ],
  "bemoan": [
    "Residents continue to complain sadly that the town's old cinema has gone.",
    "Complaining about having too little time is easier than changing what matters most to you.",
    "Critics often complain sadly about the fall in the number of independent bookshops.",
    "Instead of complaining sadly about the result, the team studied its mistakes.",
    "Older residents still express sadness that the historic market was knocked down."
  ],
  "nirvana": [
    "To the tired hikers, the quiet cabin seemed like a perfect place of peace.",
    "The retreat promised a perfect, peaceful escape from endless phone alerts.",
    "After the freezing journey, a warm room seemed completely peaceful and perfect.",
    "For someone who loved reading, the silent library was a perfect place.",
    "Fans described the small concert as a perfect musical experience."
  ],
  "cast-iron": [
    "The investigators needed a completely convincing explanation with clear evidence.",
    "Nothing makes it completely certain that the plan will succeed.",
    "The evidence helped, but it did not prove the case beyond doubt.",
    "Security video gave her an alibi that nobody could question.",
    "There is no completely reliable rule that works in every situation."
  ],
  "genre": [
    "Science fiction is the type of literature she reads most often.",
    "The director mixed features from several different types of film.",
    "A memoir is a very different type of writing from a fantasy novel.",
    "Jazz is the type of music that first inspired him.",
    "The book is hard to classify because it mixes several types of writing."
  ],
  "prickle": [
    "The rough wool made the skin on my neck feel sharp little tingles.",
    "A sudden feeling of danger made his scalp tingle sharply.",
    "The nettles made the skin on her arms feel sharp little tingles.",
    "His skin began to tingle as cold air entered the room.",
    "The suspense gave me a sharp tingling feeling at the back of my neck."
  ],
  "fiction": [
    "The story seems realistic, but its characters and events are imaginary.",
    "Historical stories often mix invented characters with events that really happened.",
    "The documentary carefully shows the difference between real information and invented material.",
    "She is most famous for writing imaginary stories about crime.",
    "The character seems believable even though he exists only in an imaginary story."
  ],
  "meander": [
    "The river begins to curve slowly across the flat valley instead of flowing straight.",
    "Without a clear main argument, the essay may move loosely from one idea to another.",
    "The path seems to wind through the meadow before it reaches the lake.",
    "Without a plan, the discussion began to move from topic to topic.",
    "We watched visitors wander slowly along the waterfront."
  ],
  "enamel": [
    "A hard, shiny blue coating protected the old metal bowl.",
    "Sugary drinks can slowly damage the hard outer layer of a tooth.",
    "A bright red, shiny coating covered the outside of the metal pan.",
    "When the mug fell, a small piece of its shiny outer coating broke off.",
    "The dentist explained that the tooth's protective outer layer had worn away."
  ],
  "meet": [
    "The school will hold an organised athletics competition on Friday afternoon.",
    "She broke the record at the regional swimming competition.",
    "The fastest runners earned places in the national track competition.",
    "Her first gymnastics competition of the season is on Saturday.",
    "Hundreds of families went to the school's yearly sports competition."
  ],
  "a-screeching-halt": [
    "The construction project stopped suddenly when its money ran out.",
    "All traffic stopped suddenly after the accident blocked both lanes.",
    "The talks stopped suddenly after both sides rejected the proposal.",
    "Production stopped completely when the main machine broke down.",
    "The lively conversation suddenly stopped when the announcement began."
  ],
  "nuance": [
    "A good translation keeps every small difference in meaning from the original argument.",
    "Her performance showed all the character's small emotional details.",
    "The shorter translation was correct but lost some small differences in meaning.",
    "Experienced readers can notice every small change in the speaker's tone.",
    "A tiny change in the words altered the sentence's suggested meaning."
  ],
  "eerie": [
    "A strange, frightening quietness covered the unused train station.",
    "In the weak moonlight, the empty playground looked strange and frightening.",
    "A mysterious, frightening light shone from the windows of the empty building.",
    "The recording contained a strange, frightening noise that nobody could recognize.",
    "The complete stillness made the forest feel strange, mysterious, and frightening."
  ],
  "tingle": [
    "The cold wind gave my fingertips a light pins-and-needles feeling.",
    "As the results were announced, excitement caused a light prickling feeling on her skin.",
    "My fingers felt slightly prickly after I entered the warm room.",
    "The exciting news gave her a light prickling feeling throughout her body.",
    "Cool water from the waterfall gave our faces a light prickling feeling."
  ],
  "trudge": [
    "After the long match, we had to walk slowly and heavily back up the hill.",
    "The hikers kept walking slowly with heavy effort through the deep mud.",
    "We had to walk slowly across the field because our bags were heavy.",
    "The tired players walked slowly and heavily toward the changing rooms.",
    "Commuters kept walking slowly with difficulty through snow reaching their ankles."
  ],
  "parch": [
    "Several rainless weeks began to make the nearby fields extremely dry.",
    "The dry desert air seemed to make his throat extremely dry.",
    "Hours of hot wind can dry the soil so much that it cracks.",
    "The salty meal made his mouth extremely dry and left him thirsty.",
    "Strong sunshine was likely to dry the young plants too much."
  ],
  "lurking": [
    "The report revealed a hidden danger under the calm appearance.",
    "She had an uncomfortable feeling that a hidden problem was waiting close by.",
    "A hidden software fault caused problems several weeks later.",
    "The calm conversation could not hide the unspoken tension waiting beneath it.",
    "They searched the bushes for any animal hiding and waiting close by."
  ],
  "wobble": [
    "The table began to move unsteadily from side to side whenever someone touched it.",
    "Careful questions caused his confidence to become less steady.",
    "The wheel will move unevenly from side to side if it is fitted incorrectly.",
    "After two steps, the child began to lose balance and move from side to side.",
    "Their lead became less secure during the final minutes of the match."
  ],
  "pellet": [
    "Each small piece of compressed food held a measured quantity of grain.",
    "The machine pressed the material into one small, rounded piece.",
    "The owl coughed up a small, rounded mass containing tiny bones.",
    "Put only one small piece of compressed fuel into the burner at a time.",
    "The rabbit took each small piece of compressed food from the bowl."
  ],
  "pounding": [
    "Sudden, heavy repeated knocks on the front door woke everyone in the house.",
    "Before the race, she could feel her heart beating quickly and strongly.",
    "Heavy repeated noises from the upstairs room continued until midnight.",
    "After the noisy trip, he woke with strong, repeated pain in his head.",
    "We heard the steady, heavy beats of drums from the other side of the field."
  ],
  "sheaf": [
    "He arrived carrying a thick bundle of handwritten notes.",
    "The farmer tied the cut wheat stalks into a tidy bundle.",
    "The lecturer gave me a bundle of research papers.",
    "A golden bundle of barley stalks stood beside the farm gate.",
    "She looked through a bundle of letters held together with string."
  ],
  "inexplicable": [
    "For a reason nobody could understand, every clock in the building had stopped.",
    "The data showed a drop that nobody could explain, so more research was needed.",
    "Nobody could explain why he suddenly refused to attend.",
    "An error nobody could explain appeared although the code had not changed.",
    "The lights went out for no understandable reason, then came back moments later."
  ],
  "recast": [
    "The editor decided to change the article into a personal story.",
    "We can present the problem differently, as a chance to design the system again.",
    "The director chose to turn the comedy into a modern story set in a school.",
    "Try to express your main claim again using simpler words.",
    "New evidence may present the debate in a more positive way."
  ],
  "exacting": [
    "Repairing the damaged painting was slow work that required great care and skill.",
    "The laboratory has very demanding rules for accuracy.",
    "The job needs patience and extremely careful attention to every detail.",
    "Making the tiny model was difficult work requiring great care and precision.",
    "Only work meeting the judge's very demanding conditions reached the final stage."
  ],
  "laden": [
    "The branches were heavily covered with wet snow.",
    "His speech was filled with references that few people listening could understand.",
    "The cart came back from the fruit farm heavily loaded with apples.",
    "Dark clouds full of rain gathered above the hills.",
    "Her answer was full of irony that some readers did not notice."
  ],
  "wreak": [
    "The powerful storm could cause widespread destruction along the coast.",
    "One false online rumour can cause a huge amount of damage.",
    "Strong winds can cause serious damage to communities by the coast.",
    "One careless error may badly harm an otherwise strong argument.",
    "The non-native insects could cause destruction throughout the crops."
  ],
  "devastation": [
    "Photographs showed the severe destruction that the flood had left behind.",
    "Even years later, the forest still showed signs of the fire's widespread damage.",
    "The community worked together to recover from the severe damage caused by the storm.",
    "The documentary showed the serious environmental damage caused by the long period without rain.",
    "Her face showed how deeply upset she was when the project was cancelled."
  ],
  "loom": [
    "As the fog became thicker, we could see a dark tower appearing as a large, threatening shape ahead.",
    "A very large cliff appeared high above the narrow road and seemed threatening.",
    "As the deadline came closer, several difficult decisions started to seem large, worrying, and hard to avoid.",
    "Tall buildings rose high on both sides of the narrow streets in the old district.",
    "In the fog, the shape of a ship appeared large and unclear in front of us."
  ],
  "stifle": [
    "Too many rules may stop students from thinking creatively in the classroom.",
    "He tried to hold back his laughter during the serious announcement.",
    "The thick smoke seemed to make every sound in the room quieter.",
    "Fear of being criticised can prevent people from having an open and honest discussion.",
    "She covered her mouth to hold back a sudden yawn."
  ],
  "oppressive": [
    "The heavy summer heat made the room feel extremely uncomfortable and hard to breathe in.",
    "The novel shows people living under a cruel government that controls their lives.",
    "The air was so hot and wet that even a short walk was exhausting.",
    "The characters fight against a cruel social system that controls and limits them.",
    "Heavy clouds made the afternoon feel dark, uncomfortable, and worrying."
  ],
  "bicker": [
    "The brothers and sisters kept having small arguments about who would sit beside the window.",
    "Team members started arguing about unimportant details instead of working on the problem.",
    "The neighbours often had small arguments about where the fence should be.",
    "The meeting will be wasted if we keep arguing about the exact words.",
    "The two friends sometimes have small arguments, but they soon become friendly again."
  ],
  "tatty": [
    "He took an old, worn notebook from the bottom of his bag.",
    "The curtains were once elegant, but now they looked faded and worn.",
    "An old, damaged poster was coming off the station wall.",
    "She replaced the worn and damaged cover of her favourite book.",
    "The outside of the café looked old and untidy, but it was pleasant inside."
  ],
  "seamless": [
    "The new system should make the change between lessons smooth, with no awkward break.",
    "Her editing made each scene connect smoothly to the next without any awkward break.",
    "Careful planning made the move to the new classroom smooth and trouble-free.",
    "The dancers performed smoothly from start to finish, with no pauses that people could see.",
    "The app connects reading and practice smoothly, without any awkward break."
  ],
  "luxuriate": [
    "After walking in the cold, we could deeply enjoy the comfort and warmth of the café.",
    "She let herself fully enjoy the unusual silence in the empty house.",
    "During the quiet afternoon, he could take great pleasure in reading for a long time without interruption.",
    "The cats stretched out and enjoyed the warm sunlight in complete comfort.",
    "After finishing the exam, we stopped to enjoy our feeling of relief fully."
  ],
  "mill-about": [
    "Visitors kept walking near the entrance without a clear purpose while they waited.",
    "Without instructions, the students started moving through the corridor in a confused group.",
    "Tourists walked without a clear purpose in the square while the guide bought tickets.",
    "After the event ended, people stayed outside the hall, moving slowly with nowhere particular to go.",
    "Because there were no assigned seats, guests gathered and moved without purpose near the doorway."
  ],
  "flank": [
    "Tall trees stood in rows along both sides of the road.",
    "One stone tower stood on each side of the castle's main entrance.",
    "Two rows of lamps stood along both sides of the path to the theatre.",
    "Low hills stood on the eastern and western sides of the village.",
    "Matching bookshelves stood on both sides of the fireplace in the reading room."
  ],
  "scramble": [
    "We had to climb quickly and with difficulty over loose rocks to reach the ridge.",
    "Reporters began competing urgently for the small number of seats in the hall.",
    "After leaving the boat, passengers had to climb the steep bank quickly and with difficulty.",
    "Several teams will compete and hurry to finish before the deadline.",
    "At low tide, the children started climbing quickly over the rocks using their hands and feet."
  ],
  "obscure": [
    "Low clouds began to hide the top of the mountain from view.",
    "Most readers were confused by the writer's little-known and difficult references.",
    "Dust from the road may cover the warning sign and make it difficult to see.",
    "The poem mentions a local legend that few people know.",
    "Technical language can make a simple, useful idea difficult to understand."
  ],
  "teeter": [
    "The pile of books started balancing unsteadily near the edge of the desk.",
    "For several weeks, the project seemed very close to failing.",
    "The cup seemed to balance unsteadily on the narrow shelf and could easily fall.",
    "As the rider slowed down, the bicycle began moving from side to side and nearly falling.",
    "The organisation remained in an uncertain position between recovering and closing."
  ],
  "recede": [
    "As the boat moved away, the shoreline seemed to move farther into the distance.",
    "The noise slowly became quieter as it moved farther away.",
    "As the tide moved away from the shore, a wide area of sand appeared.",
    "As the train crossed the plain, the mountains seemed to become more distant.",
    "Once she understood the instructions, her worries gradually became weaker."
  ],
  "heave": [
    "They had to lift the wet, heavy bag onto the platform with great effort.",
    "Using all their remaining strength, the workers finally pulled the door open.",
    "We used great effort together to lift the fallen branch off the path.",
    "The sailors began pulling the heavy rope onto the deck with great effort.",
    "He had to lift the heavy suitcase into the luggage rack with great effort."
  ],
  "sodden": [
    "After several hours of rain, our clothes were completely wet and heavy.",
    "The gardener lifted a pile of leaves that were extremely wet and heavy from the path.",
    "The rain made the entire playing field extremely wet.",
    "She hung her completely wet coat beside the heater.",
    "After we crossed the marsh, our shoes were full of water and felt heavy."
  ],
  "strand": [
    "One thin piece of hair was lying across the page.",
    "A broken machine could leave the hikers unable to return from their remote location.",
    "A loose piece of wool hung from the sleeve.",
    "Cancelled trains could leave hundreds of passengers unable to travel home overnight.",
    "The mystery is one part of the novel's complicated story."
  ],
  "synthesise": [
    "A good conclusion should combine evidence from different parts of the passage into one clear idea.",
    "The report must combine information from several sources instead of describing each one separately.",
    "You need to combine the interviews into one clear explanation.",
    "The final paragraph should bring the essay's main ideas together.",
    "Good researchers connect information into a whole instead of simply listing facts."
  ],
  "rugged": [
    "Only skilled walkers tried the difficult, rocky mountain route.",
    "The vehicle was built for rough, uneven ground.",
    "The rescue team crossed a rough, rocky part of the coast.",
    "These boots are suitable for rough paths and rocky slopes.",
    "The actor's face looked strong and rough, with deep lines."
  ],
  "spurt": [
    "Water began to shoot forcefully from a crack in the pipe.",
    "The company grew quickly for a short time at the end of the year.",
    "Ink began to shoot from the damaged cartridge.",
    "The runner made one final short burst of speed near the finish.",
    "Young plants often grow quickly upwards after several warm days."
  ],
  "curb": [
    "The new policy aims to reduce waste that is not needed.",
    "She found it difficult to control her impatience during the long delay.",
    "Better insulation can help reduce the amount of energy used at home.",
    "The car stopped beside the raised border separating the road from the pavement.",
    "Public criticism limited how far he could pursue his ambitions."
  ],
  "trafficking": [
    "The investigation examined the illegal trade in protected wild animals.",
    "Countries need to work together to prevent the illegal movement and sale of people.",
    "Stronger checks were introduced to stop the illegal wildlife trade.",
    "The charity teaches people about the illegal trade in humans and helps to prevent it.",
    "Police from several countries worked together to investigate the illegal trade in art."
  ],
  "snare": [
    "The ranger removed an illegal trap from the forest.",
    "The dishonest offer was created to trap customers who were not careful.",
    "Someone had placed a hidden trap beside the animal path.",
    "Unclear promises can trap people in unfair agreements.",
    "The photographer hoped to capture the perfect moment in a picture."
  ],
  "swerve": [
    "The cyclist had to change direction suddenly to avoid a fallen branch.",
    "The driver was forced to turn sharply away from the object blocking the way.",
    "The bus had to change direction suddenly around a large hole in the road.",
    "She changed direction suddenly without losing control of the bicycle.",
    "A sudden turn to the left helped the driver avoid the fallen tree."
  ],
  "glitz": [
    "Behind the awards ceremony's bright glamour were months of careful work.",
    "The campaign used exciting celebrity glamour instead of a believable message.",
    "The festival had plenty of showy excitement but little original music.",
    "She preferred the quiet rehearsal to the showy glamour of opening night.",
    "The shop's holiday display gave the ordinary street a bright, glamorous look."
  ],
  "ostentation": [
    "The simple room was designed without luxury or showy displays.",
    "His quiet generosity was very different from the public event's showy display.",
    "The architect preferred simplicity and avoided showy displays intended to impress people.",
    "They celebrated warmly but without an unnecessary display of wealth.",
    "The critic disliked the restaurant's wealth and its showy display."
  ],
  "reap": [
    "Students who practise regularly will receive the benefits later.",
    "The farmers were ready to harvest the wheat at the end of summer.",
    "If you revise regularly, you should receive rewards in the quiz.",
    "The village hopes to collect a larger harvest this season.",
    "Communities that protect wetlands receive benefits that last a long time."
  ],
  "respiratory": [
    "Air pollution can cause problems with breathing.",
    "The athlete was checked for signs of an infection affecting the breathing organs.",
    "The clinic recorded more illnesses affecting breathing during winter.",
    "Clean air is necessary to keep the lungs and breathing system healthy.",
    "The mask protected workers from breathing problems caused by dust."
  ],
  "incinerator": [
    "Waste that could not be recycled was taken to the city's high-temperature burning machine.",
    "The hospital uses a special machine to burn certain kinds of waste.",
    "The council checks gases released by the machine that burns waste.",
    "A modern waste-burning machine can produce energy while dealing with some rubbish.",
    "The old waste-burning machine was closed until its filters could be replaced."
  ],
  "shredder": [
    "Old private documents were put into a machine that cuts them into small pieces.",
    "The garden machine cut the branches into small chips.",
    "Put only a few sheets into the paper-cutting machine at one time.",
    "A machine for cutting leaves helped turn garden waste into material for the soil.",
    "The office bought a quieter paper-cutting machine for private documents."
  ],
  "elaborate": [
    "A complex, detailed network of lights and cables covered the stage.",
    "Could you explain the final point in your argument in more detail?",
    "The museum showed a very detailed model of the ancient city.",
    "Please explain in more detail how the evidence supports your conclusion.",
    "They developed a complex, detailed system of signals for the performance."
  ],
  "nostalgia": [
    "The old photos made her miss the time when she was a child.",
    "Visitors enjoy the exhibition because it brings back warm memories of early video games.",
    "The sound of the old school bell brought back strong memories of the past.",
    "The film's music creates a soft, warm feeling about the past.",
    "He remembered village life warmly but forgot that it also had problems."
  ],
  "wail": [
    "The baby began crying loudly and for a long time when the room suddenly became dark.",
    "Far away, a siren began making a long, high sound through the empty streets.",
    "The wind began making a long, high noise around the corners of the house.",
    "A child began crying loudly after she could no longer see her group.",
    "The alarm's long, high sound could be heard above the machinery."
  ],
  "quadruple": [
    "Online orders could grow to four times their usual number during the holidays.",
    "The upgraded server could store four times as much data as the old one.",
    "There may be four times as many seedlings by the end of the month.",
    "Demand could grow to four times its current level if the product becomes cheaper.",
    "The new hall provides four times as much seating space for students."
  ],
  "daunting": [
    "Reading all five lists at the same time can seem very difficult.",
    "From the bottom of the mountain, the climb looked difficult and frightening.",
    "The first page was hard, but the pages after it seemed easier and less frightening.",
    "Putting many years of records in order seemed like a very difficult job.",
    "Speaking in front of many people can seem frightening at first."
  ],
  "self-contained-bubble": [
    "The remote campus sometimes felt like an isolated place with little contact with the city.",
    "Working only with the same small group kept the team separate from outside people and ideas.",
    "During the retreat, the group lived in an isolated setting away from everyday distractions.",
    "During the long winter, the research station worked as an isolated place with little outside contact.",
    "Online communities can become closed spaces where people rarely hear opinions from outside."
  ],
  "prevalent": [
    "Many younger readers still share this belief.",
    "This problem happens very often in crowded city areas.",
    "Remote working became more common throughout the industry.",
    "This custom is still common in the country's rural areas.",
    "False information is especially common when people cannot easily find trustworthy sources."
  ],
  "yank": [
    "Do not pull the cable suddenly; take it carefully out of the socket.",
    "She had to pull the stuck drawer open with a sudden, strong movement.",
    "A sudden wave seemed to pull the rope sharply out of his hand.",
    "She had to pull the curtain sharply to one side so she could open the window.",
    "Do not pull a page out of the notebook suddenly; remove it carefully."
  ],
  "smug": [
    "His overly pleased smile disappeared when the final result was announced.",
    "The narrator sounds too pleased with himself, so the character is difficult to like.",
    "The winner looked too pleased with himself, which annoyed the other competitors.",
    "He sounded too pleased with himself when he said the task was easy.",
    "Her overconfident attitude disappeared as soon as people began asking questions."
  ],
  "brow": [
    "She wiped the rain from her forehead and continued walking.",
    "When they reached the top edge of the hill, they could see the whole valley.",
    "A deep line appeared across his forehead while he concentrated.",
    "They stopped at the top edge of the slope before walking down.",
    "She used one hand to shade her forehead while looking towards the sun."
  ],
  "sprawl": [
    "New suburbs continue to spread over a wide area beyond the old city boundary.",
    "Seen from above, the city's wide and irregular growth reached towards the coast.",
    "Vines began to spread in different directions across the garden wall.",
    "Maps show how the city's irregular growth has covered nearby farmland.",
    "After walking a long way, he wanted to lie on the sofa with his legs stretched out."
  ],
  "verdant": [
    "Rain had turned the dry valley into a green landscape full of plants.",
    "The house stood between rich green fields and thick woods.",
    "A narrow path curved through the rich green gardens.",
    "From the ridge, we looked down at a rich green plain.",
    "Because of the rainy climate, the northern hills stay rich and green all year."
  ],
  "jolt": [
    "The bus made a sudden, rough movement as it crossed the uneven road.",
    "The unexpected announcement gave everyone a sudden shock that made them act.",
    "The train stopped with a sudden, rough movement.",
    "Cold water may give you a sudden shock and wake you up in the morning.",
    "The disappointing score gave the team a useful shock before the final."
  ],
  "compose-yourself": [
    "Take a moment to become calm and control your emotions before starting the presentation.",
    "After the tense meeting, he went outside briefly to calm down and regain control.",
    "Pause and calm down before you answer the difficult question.",
    "You have a few minutes to calm down and control your emotions before the interview.",
    "After the surprise, she briefly closed her eyes to become calm again."
  ],
  "foreboding": [
    "The darkening sky made the travellers feel that something bad was going to happen.",
    "Before the announcement, a worrying silence filled the house and seemed to warn of trouble.",
    "As the path became narrower, they increasingly felt that something bad might happen.",
    "Sound and shadow make the opening scene feel as if something bad will happen.",
    "His repeated warnings made the group feel that trouble was coming."
  ],
  "bestir": [
    "He finally became active and started organising the neglected room.",
    "The sleepy village did not become active until long after sunrise.",
    "We must get moving if we want to finish before noon.",
    "The town became active as the first shops opened.",
    "She finally decided to take action and answer the waiting messages."
  ]
};
