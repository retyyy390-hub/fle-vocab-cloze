export const EXTRA_EXAMPLES: Record<string, string[]> = {
  gist: [
    "The summary captures the ____ of the report without every detail.",
    "Without reading every page, she still grasped the ____ of the proposal.",
    "Can you explain the ____ of his complaint in one sentence?",
  ],
  annotate: [
    "As you read, ____ any phrase that reveals the narrator's attitude.",
    "Researchers often ____ photographs to identify important features.",
    "Use brief margin notes to ____ the chapter before class.",
  ],
  hoist: [
    "A pulley helped them ____ the crate onto the upper floor.",
    "At sunrise, the crew gathered to ____ the flag.",
    "Four people were needed to ____ the heavy beam into place.",
  ],
  "criss-cross": [
    "Narrow canals ____ the old quarter of the city.",
    "Fine cracks ____ the dry ground after weeks without rain.",
    "Bus routes ____ the centre, linking every major district.",
  ],
  bemoan: [
    "Critics often ____ the decline of independent bookshops.",
    "Rather than ____ the result, the team examined what went wrong.",
    "Older residents still ____ the demolition of the historic market.",
  ],
  nirvana: [
    "After the freezing journey, a warm room seemed like ____.",
    "For a serious reader, the silent library was pure ____.",
    "Fans described the intimate concert as musical ____.",
  ],
  "cast-iron": [
    "The evidence was useful, but it did not create a ____ case.",
    "Security footage gave her a ____ alibi.",
    "There is no ____ rule that works in every situation.",
  ],
  genre: [
    "A memoir belongs to a very different ____ from a fantasy novel.",
    "Jazz is the musical ____ that first inspired him.",
    "The book is difficult to classify because it mixes more than one ____.",
  ],
  prickle: [
    "The nettles made the skin on her arms ____.",
    "His skin began to ____ as the cold air entered the room.",
    "The suspense made the back of my neck ____.",
  ],
  fiction: [
    "The documentary carefully separates fact from ____.",
    "She is best known for writing crime ____.",
    "The character feels convincing even though he belongs entirely to ____.",
  ],
  meander: [
    "The path appears to ____ through the meadow before reaching the lake.",
    "Without an agenda, the discussion began to ____.",
    "We watched visitors ____ slowly along the waterfront.",
  ],
  enamel: [
    "Bright red ____ covered the outside of the metal pan.",
    "Dropping the mug caused a small piece of ____ to chip away.",
    "The dentist explained that the protective ____ had become worn.",
  ],
  meet: [
    "The fastest runners qualified for the national track ____.",
    "Her first gymnastics ____ of the season takes place on Saturday.",
    "Hundreds of families attended the annual school sports ____.",
  ],
  "a-screeching-halt": [
    "Negotiations came to ____ after both sides rejected the proposal.",
    "Production ground to ____ when the main machine failed.",
    "The lively conversation came to ____ when the announcement began.",
  ],
  nuance: [
    "The shorter translation was accurate but lost some ____.",
    "Experienced readers can distinguish each ____ in the speaker's tone.",
    "A subtle ____ in the wording changed the implication of the sentence.",
  ],
  eerie: [
    "An ____ glow came from the windows of the empty building.",
    "The recording captured an ____ sound that no one could identify.",
    "Everything was still, giving the forest an ____ atmosphere.",
  ],
  tingle: [
    "My fingers began to ____ after I stepped into the warm room.",
    "The exciting announcement made her whole body ____.",
    "A cool spray from the waterfall made our faces ____.",
  ],
  trudge: [
    "We had to ____ across the field with our heavy bags.",
    "The tired players began to ____ towards the changing rooms.",
    "Commuters continued to ____ through the ankle-deep snow.",
  ],
  parch: [
    "Hours of hot wind can ____ the soil until it cracks.",
    "The salty meal began to ____ his mouth.",
    "Strong sunlight threatened to ____ the young plants.",
  ],
  lurking: [
    "A ____ flaw in the software caused problems weeks later.",
    "The calm discussion could not hide the ____ tension in the room.",
    "They checked the bushes for any animal ____ nearby.",
  ],
  wobble: [
    "The wheel will ____ if it is not fitted properly.",
    "The child took two steps before beginning to ____.",
    "Their lead started to ____ during the final minutes of the match.",
  ],
  pellet: [
    "The owl coughed up a small ____ containing tiny bones.",
    "Place one fuel ____ in the burner at a time.",
    "The rabbit picked up each food ____ from the bowl.",
  ],
  pounding: [
    "The ____ from the room upstairs continued until midnight.",
    "He woke with a ____ in his head after the noisy journey.",
    "We heard the steady ____ of drums from across the field.",
  ],
  sheaf: [
    "The lecturer handed me a ____ of research papers.",
    "A golden ____ of barley stood beside the farm gate.",
    "She sorted through a ____ of letters tied with string.",
  ],
  inexplicable: [
    "His sudden refusal to attend was completely ____.",
    "An ____ error appeared even though the code had not changed.",
    "The lights went out for an ____ reason and returned moments later.",
  ],
  recast: [
    "The director chose to ____ the comedy as a modern school story.",
    "Try to ____ your main claim in simpler language.",
    "New evidence may ____ the debate in a more positive light.",
  ],
  exacting: [
    "The role requires patience and an ____ attention to detail.",
    "Preparing the miniature model was an ____ task.",
    "Only work that met the judge's ____ requirements reached the final.",
  ],
  laden: [
    "The cart returned from the orchard ____ with apples.",
    "Dark clouds ____ with rain gathered over the hills.",
    "Her reply was ____ with irony that some readers missed.",
  ],
  wreak: [
    "Severe winds can ____ havoc on coastal communities.",
    "A careless mistake may ____ damage on an otherwise strong argument.",
    "The invasive insects could ____ destruction across the crops.",
  ],
  devastation: [
    "The community worked together to recover from the storm's ____.",
    "The documentary showed the environmental ____ caused by the drought.",
    "Her expression revealed her ____ when the project was cancelled.",
  ],
  loom: [
    "With the deadline approaching, several difficult decisions began to ____.",
    "Tall buildings ____ over the narrow streets of the old district.",
    "Through the fog, the outline of a ship seemed to ____ in front of us.",
  ],
  stifle: [
    "The thick smoke seemed to ____ every sound in the room.",
    "Fear of criticism can ____ an honest discussion.",
    "She covered her mouth to ____ a sudden yawn.",
  ],
  oppressive: [
    "An ____ humidity made even a short walk exhausting.",
    "The characters struggle against an ____ social system.",
    "Heavy clouds gave the afternoon an ____ mood.",
  ],
  bicker: [
    "The neighbours used to ____ about the position of the fence.",
    "We will waste the meeting if we continue to ____ over wording.",
    "The two friends may ____ occasionally, but they quickly make peace.",
  ],
  tatty: [
    "A ____ poster was peeling from the station wall.",
    "She replaced the ____ cover on her favourite book.",
    "The café looked rather ____ outside but was welcoming within.",
  ],
  seamless: [
    "Careful planning made the move to the new classroom ____.",
    "The dancers gave a ____ performance with no visible pauses.",
    "The app offers a ____ link between reading and practice.",
  ],
  luxuriate: [
    "On the quiet afternoon, he could ____ in a long, uninterrupted read.",
    "The cats stretched out to ____ in the sunlight.",
    "After finishing the exam, we stopped to ____ in the sense of relief.",
  ],
  "mill-about": [
    "Tourists began to ____ in the square while the guide bought tickets.",
    "People continued to ____ outside the hall after the event ended.",
    "Without assigned seats, guests tended to ____ near the doorway.",
  ],
  flank: [
    "Two rows of lamps ____ the path to the theatre.",
    "Low hills ____ the village to the east and west.",
    "Matching bookshelves ____ the fireplace in the reading room.",
  ],
  scramble: [
    "Passengers had to ____ up the steep bank after leaving the boat.",
    "Several teams will ____ to finish before the deadline.",
    "The children began to ____ across the rocks at low tide.",
  ],
  obscure: [
    "Dust from the road may ____ the warning sign.",
    "The poem refers to an ____ legend from the region.",
    "Technical language can ____ a simple and useful idea.",
  ],
  teeter: [
    "The cup appeared to ____ on the narrow shelf.",
    "The bicycle began to ____ as the rider slowed down.",
    "The organisation continued to ____ between recovery and closure.",
  ],
  recede: [
    "When the tide began to ____, a wide stretch of sand appeared.",
    "The mountains seemed to ____ as the train crossed the plain.",
    "Her worries started to ____ once she understood the instructions.",
  ],
  heave: [
    "We worked together to ____ the fallen branch off the path.",
    "The sailors began to ____ the rope onto the deck.",
    "He had to ____ the suitcase into the luggage rack.",
  ],
  sodden: [
    "The rain left the playing field completely ____.",
    "She hung her ____ coat beside the heater.",
    "Our shoes became heavy and ____ after crossing the marsh.",
  ],
  strand: [
    "A loose ____ of wool hung from the sleeve.",
    "Cancelled trains could ____ hundreds of passengers overnight.",
    "The mystery is one ____ of the novel's complex plot.",
  ],
  synthesise: [
    "You need to ____ the interviews into one clear explanation.",
    "The final paragraph should ____ the essay's main ideas.",
    "Good researchers ____ information instead of listing facts.",
  ],
  rugged: [
    "The rescue team crossed a ____ stretch of coastline.",
    "These boots are suitable for ____ paths and rocky slopes.",
    "The actor's ____ face had strong features and deep lines.",
  ],
  spurt: [
    "Ink began to ____ from the damaged cartridge.",
    "The runner produced a final ____ of speed near the finish.",
    "Seedlings often ____ upwards after several warm days.",
  ],
  curb: [
    "Better insulation can help ____ household energy use.",
    "The car stopped beside the raised ____ at the edge of the road.",
    "Public criticism acted as a ____ on his ambitions.",
  ],
  trafficking: [
    "Stronger checks were introduced to stop wildlife ____.",
    "The charity raises awareness of human ____ and supports prevention.",
    "Police from several countries cooperated to investigate art ____.",
  ],
  snare: [
    "A hidden ____ had been placed beside the animal trail.",
    "Vague promises can ____ people into unfair agreements.",
    "The photographer hoped to ____ the perfect moment on camera.",
  ],
  swerve: [
    "The bus had to ____ around a large hole in the road.",
    "She managed to ____ without losing control of the bicycle.",
    "A sudden ____ to the left kept the driver away from the fallen tree.",
  ],
  glitz: [
    "The festival offered plenty of ____ but little original music.",
    "She preferred the quiet rehearsal to the ____ of opening night.",
    "The shop's holiday display added ____ to the ordinary street.",
  ],
  ostentation: [
    "The architect valued simplicity and avoided ____.",
    "They celebrated with warmth but without unnecessary ____.",
    "The critic disliked the restaurant's wealth and ____.",
  ],
  reap: [
    "If you revise steadily, you should ____ the rewards in the quiz.",
    "The village hopes to ____ a larger harvest this season.",
    "Communities that protect wetlands ____ long-term benefits.",
  ],
  respiratory: [
    "The clinic recorded a rise in ____ illnesses during winter.",
    "Clean air is essential for good ____ health.",
    "The mask helped protect workers from ____ irritation caused by dust.",
  ],
  incinerator: [
    "The council monitors emissions from the waste ____.",
    "A modern ____ can recover energy while processing some rubbish.",
    "The old ____ was closed until its filters could be replaced.",
  ],
  shredder: [
    "Feed only a few sheets into the paper ____ at once.",
    "A leaf ____ helped turn garden waste into mulch.",
    "The office bought a quieter ____ for confidential paperwork.",
  ],
  elaborate: [
    "The museum displayed an ____ model of the ancient city.",
    "Please ____ on how the evidence supports your conclusion.",
    "They developed an ____ system of signals for the performance.",
  ],
  nostalgia: [
    "Hearing the old school bell stirred a wave of ____.",
    "The film uses music to create a gentle sense of ____.",
    "His ____ for village life ignored some of its difficulties.",
  ],
  wail: [
    "The wind began to ____ around the corners of the house.",
    "A child started to ____ after losing sight of her group.",
    "The long, high ____ of an alarm rose above the noise of the machinery.",
  ],
  quadruple: [
    "The number of seedlings may ____ by the end of the month.",
    "Demand could ____ if the product becomes cheaper.",
    "The new hall has ____ the seating space available to students.",
  ],
  daunting: [
    "The first page was complex, but the rest felt less ____.",
    "Organising years of records seemed like a ____ job.",
    "Speaking to a large audience can be ____ at first.",
  ],
  "self-contained-bubble": [
    "During the retreat, the group lived in a ____ away from daily distractions.",
    "The research station operated as a ____ during the long winter.",
    "Online communities can become a ____ with few outside opinions.",
  ],
  prevalent: [
    "Remote working became more ____ across the industry.",
    "The custom is still ____ in rural parts of the country.",
    "Misinformation is most ____ when reliable sources are hard to find.",
  ],
  yank: [
    "A sudden wave seemed to ____ the rope from his hand.",
    "She had to ____ the curtain aside to open the window.",
    "Do not ____ a page from the notebook; remove it carefully.",
  ],
  smug: [
    "The winner's ____ expression irritated the other competitors.",
    "He sounded ____ when he claimed that the task was easy.",
    "Her ____ certainty vanished as soon as the questions began.",
  ],
  brow: [
    "A deep line appeared across his ____ as he concentrated.",
    "They paused at the ____ of the slope before walking down.",
    "She shaded her ____ with one hand and looked towards the sun.",
  ],
  sprawl: [
    "Vines began to ____ across the garden wall.",
    "Maps reveal how the city's ____ has consumed nearby farmland.",
    "After the long walk, he wanted to ____ on the sofa with his legs stretched out.",
  ],
  verdant: [
    "A narrow path wound through the ____ gardens.",
    "From the ridge, we looked down on a ____ plain.",
    "The rainy climate keeps the northern hills ____ throughout the year.",
  ],
  jolt: [
    "The train came to a stop with a sudden ____.",
    "Cold water may ____ you awake in the morning.",
    "The disappointing score gave the team a useful ____ before the final.",
  ],
  "compose-yourself": [
    "Pause and ____ before responding to the difficult question.",
    "You have a few minutes to ____ before the interview begins.",
    "She closed her eyes briefly to ____ after the surprise.",
  ],
  foreboding: [
    "A sense of ____ grew as the path became narrower.",
    "The opening scene creates a ____ atmosphere through sound and shadow.",
    "His repeated warnings filled the group with ____.",
  ],
  bestir: [
    "We must ____ ourselves if we want to finish before noon.",
    "The town began to ____ itself as the first shops opened.",
    "She finally decided to ____ herself and answer the waiting messages.",
  ],
};
