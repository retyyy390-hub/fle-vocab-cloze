export const DAY = 24 * 60 * 60 * 1000;
export const TEN_MINUTES = 10 * 60 * 1000;
export const BEIJING_OFFSET = 8 * 60 * 60 * 1000;
export const REVIEW_INTERVALS = [1, 3, 7] as const;
export const BASE_DAILY_NEW_TARGET = 15;

export type ReviewRecord = {
  level: number;
  dueAt: number;
  introducedAt: number;
  lastSeenAt: number;
  attempts: number;
  correct: number;
};

export type ReviewState = Record<string, ReviewRecord>;
export type ReviewOutcome = "correct" | "hint" | "wrong";

export function beijingDayStart(timestamp: number) {
  return Math.floor((timestamp + BEIJING_OFFSET) / DAY) * DAY - BEIJING_OFFSET;
}

export function beijingDateKey(timestamp: number) {
  return String(Math.floor((timestamp + BEIJING_OFFSET) / DAY));
}

export function beijingDueAt(timestamp: number, days: number) {
  return beijingDayStart(timestamp) + days * DAY;
}

function dueLabel(days: number) {
  if (days === 1) return "北京时间明天（D+1）";
  return "北京时间" + days + "个自然日后（D+" + days + "）";
}

export function scheduleReview(
  previous: ReviewRecord | undefined,
  timestamp: number,
  outcome: ReviewOutcome,
) {
  let level = previous?.level ?? 0;
  let dueAt = beijingDueAt(timestamp, 1);
  let nextReview = "北京时间明天（D+1）";

  if (outcome === "correct") {
    const canAdvance = !previous || previous.level === 0 ||
      (previous.dueAt <= timestamp &&
        beijingDateKey(previous.lastSeenAt) !== beijingDateKey(timestamp));
    if (canAdvance) {
      level = Math.min(level + 1, REVIEW_INTERVALS.length);
      const interval = REVIEW_INTERVALS[Math.max(level - 1, 0)];
      dueAt = beijingDueAt(timestamp, interval);
      nextReview = dueLabel(interval);
    } else {
      dueAt = previous.dueAt;
      nextReview = "原定复习日期不变（提前或同日加练不升级）";
    }
  } else if (outcome === "hint") {
    dueAt = beijingDueAt(timestamp, 1);
    nextReview = "北京时间明天再测（使用过句意辅助）";
  } else {
    level = 0;
    dueAt = timestamp + TEN_MINUTES;
    nextReview = "北京时间10分钟后可重试";
  }

  return {
    record: {
      level,
      dueAt,
      introducedAt: previous?.introducedAt ?? timestamp,
      lastSeenAt: timestamp,
      attempts: (previous?.attempts ?? 0) + 1,
      correct: (previous?.correct ?? 0) + (outcome === "correct" ? 1 : 0),
    },
    nextReview,
  };
}

export function migrateToBeijingCalendar(state: ReviewState) {
  return Object.fromEntries(
    Object.entries(state).map(([id, record]) => {
      const previousDelay = record.dueAt - record.lastSeenAt;
      const interval = REVIEW_INTERVALS.find(
        (days) => Math.abs(previousDelay - days * DAY) < TEN_MINUTES,
      );

      return [
        id,
        interval
          ? { ...record, dueAt: beijingDueAt(record.lastSeenAt, interval) }
          : record,
      ];
    }),
  );
}

function finiteNumber(value: unknown): value is number {
  return typeof value === "number" && Number.isFinite(value);
}

export function sanitizeReviewState(
  value: unknown,
  validIds: ReadonlySet<string>,
): ReviewState {
  if (!value || typeof value !== "object" || Array.isArray(value)) return {};

  const clean: ReviewState = {};
  for (const [id, candidate] of Object.entries(value)) {
    if (!validIds.has(id) || !candidate || typeof candidate !== "object") {
      continue;
    }

    const record = candidate as Partial<ReviewRecord>;
    if (
      !finiteNumber(record.level) ||
      !finiteNumber(record.dueAt) ||
      !finiteNumber(record.introducedAt) ||
      !finiteNumber(record.lastSeenAt) ||
      !finiteNumber(record.attempts) ||
      !finiteNumber(record.correct)
    ) {
      continue;
    }

    clean[id] = {
      level: Math.min(
        REVIEW_INTERVALS.length,
        Math.max(0, Math.trunc(record.level)),
      ),
      dueAt: record.dueAt,
      introducedAt: record.introducedAt,
      lastSeenAt: record.lastSeenAt,
      attempts: Math.max(0, Math.trunc(record.attempts)),
      correct: Math.max(0, Math.trunc(record.correct)),
    };
  }

  return clean;
}

export function introducedOnDate(state: ReviewState, timestamp: number) {
  const dateKey = beijingDateKey(timestamp);
  return Object.values(state).filter(
    (record) => beijingDateKey(record.introducedAt) === dateKey,
  ).length;
}

export function dailyNewTarget(
  state: ReviewState,
  totalWords: number,
  timestamp: number,
) {
  const introducedToday = introducedOnDate(state, timestamp);
  const unseen = Math.max(0, totalWords - Object.keys(state).length);
  return Math.min(BASE_DAILY_NEW_TARGET, unseen + introducedToday);
}

export function makeReviewQueue(
  eligibleIds: readonly string[],
  state: ReviewState,
  totalWords: number,
  timestamp: number,
  extra = false,
) {
  const due = eligibleIds
    .filter((id) => state[id]?.dueAt <= timestamp)
    .sort((left, right) => state[left].dueAt - state[right].dueAt);

  const addedToday = introducedOnDate(state, timestamp);
  const target = dailyNewTarget(state, totalWords, timestamp);
  const newSlots = extra ? BASE_DAILY_NEW_TARGET : Math.max(0, target - addedToday);
  const fresh = eligibleIds.filter((id) => !state[id]).slice(0, newSlots);

  return Array.from(new Set([...due, ...fresh])).slice(0, 15);
}
