import {useEffect,useRef,useState} from 'react';
type InstallEvent=Event&{prompt:()=>Promise<void>;userChoice:Promise<{outcome:string}>};
export function usePwa(){const [canInstall,setCanInstall]=useState(false),[updateReady,setUpdateReady]=useState(false);const installer=useRef<InstallEvent|null>(null),registration=useRef<ServiceWorkerRegistration|null>(null);
 useEffect(()=>{const handler=(event:Event)=>{event.preventDefault();installer.current=event as InstallEvent;setCanInstall(true);};const installed=()=>{installer.current=null;setCanInstall(false);};window.addEventListener('beforeinstallprompt',handler);window.addEventListener('appinstalled',installed);
 if('serviceWorker' in navigator){navigator.serviceWorker.register('./sw.js').then(reg=>{registration.current=reg;if(reg.waiting&&navigator.serviceWorker.controller)setUpdateReady(true);reg.addEventListener('updatefound',()=>{reg.installing?.addEventListener('statechange',()=>{if(reg.waiting&&navigator.serviceWorker.controller)setUpdateReady(true);});});reg.update().catch(()=>{});}).catch(()=>{});}
 return()=>{window.removeEventListener('beforeinstallprompt',handler);window.removeEventListener('appinstalled',installed);};},[]);
 async function install(){if(installer.current){await installer.current.prompt();await installer.current.userChoice;installer.current=null;setCanInstall(false);}}
 function refresh(){const waiting=registration.current?.waiting;if(waiting){navigator.serviceWorker.addEventListener('controllerchange',()=>window.location.reload(),{once:true});waiting.postMessage({type:'SKIP_WAITING'});}else window.location.reload();}
 return{canInstall,updateReady,install,refresh};
}
