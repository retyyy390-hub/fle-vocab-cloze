import {BY_ID,isCorrectForm,normalizeForm,type Word,type Period} from './data.ts';
import {beijingDateKey,dailyNewTarget,introducedOnDate,scheduleReview,type ReviewState} from './review-schedule.ts';
export const VERSION='7.1';
export const KEYS={progress:'fle-vocab-cloze-progress-v1',migration:'fle-vocab-cloze-beijing-calendar-v1',mistakes:'fle-vocab-cloze-mistakes-v1',guide:'fle-vocab-cloze-guide-read-v1',draft:'fle-vocab-cloze-round-v2',history:'fle-vocab-cloze-context-history-v1',period:'fle-vocab-cloze-period-v1'};
export type Kind='new'|'due'|'free'|'mistakes';
export type Mistake={confusedWith:string[];lastMissAt:number;resolved:boolean;lastCorrectAt?:number;lastExampleIndex?:number;reason?:'word'|'form'|'hint';lastInput?:string;expected?:string};
export type Mistakes=Record<string,Mistake>;
export type History=Record<string,number[]>;
export type Round={kind:Kind;questionIds:string[];choiceIds:string[];exampleIndexes:Record<string,number>;answers:Record<string,string>;formValues:Record<string,string>;hints:string[];position:number;createdAt:number;period:Period};
export type Result={targetId:string;selectedId:string;input:string;expected:string;wordCorrect:boolean;formCorrect:boolean;correct:boolean;assisted:boolean;reason:'word'|'form'|'hint'|'correct';nextReview:string};
export type Report={round:Round;results:Result[];submittedAt:number};
export const TITLES:Record<Kind,string>={new:'新词检测',due:'到期复习',free:'自由练习',mistakes:'错词复习'};
export function shuffle<T>(values:readonly T[],random=Math.random){const a=[...values];for(let i=a.length-1;i>0;i--){const j=Math.floor(random()*(i+1));[a[i],a[j]]=[a[j],a[i]];}return a;}
function different<T>(values:readonly T[],reference:readonly T[],random=Math.random){const a=shuffle(values,random);return a.length>1&&a.length===reference.length&&a.every((x,i)=>x===reference[i])?[...a.slice(1),a[0]]:a;}
export function homeFor(kind:Kind){return kind==='free'?'free':kind==='mistakes'?'mistakes':'today';}
export function status(entry:Mistake,now:number){return entry.resolved?'resolved':entry.lastCorrectAt!==undefined&&entry.lastCorrectAt>=entry.lastMissAt&&beijingDateKey(entry.lastCorrectAt)===beijingDateKey(now)?'waiting':'pending';}
export function sanitizeMistakes(value:unknown):Mistakes {
 const out:Mistakes={};if(!value||typeof value!=='object'||Array.isArray(value))return out;
 for(const [id,raw] of Object.entries(value)) {if(!BY_ID.has(id)||!raw||typeof raw!=='object')continue;const m=raw as Mistake;if(!Number.isFinite(m.lastMissAt))continue;
  out[id]={confusedWith:Array.isArray(m.confusedWith)?[...new Set(m.confusedWith.filter(x=>BY_ID.has(x)&&x!==id))]:[],lastMissAt:m.lastMissAt,resolved:m.resolved===true,
   ...(Number.isFinite(m.lastCorrectAt)?{lastCorrectAt:m.lastCorrectAt}:{}),...(Number.isInteger(m.lastExampleIndex)&&m.lastExampleIndex!>=0?{lastExampleIndex:m.lastExampleIndex}:{}),...(['word','form','hint'].includes(m.reason??'')?{reason:m.reason}:{}),...(typeof m.lastInput==='string'?{lastInput:m.lastInput.slice(0,120)}:{}),...(typeof m.expected==='string'?{expected:m.expected.slice(0,120)}:{})};
 }return out;
}
export function todayPlan(words:readonly Word[],records:ReviewState,now:number,mistakes:Mistakes={}) {
 const ids=words.map(w=>w.id);const active=Object.fromEntries(Object.entries(records).filter(([id])=>ids.includes(id)));
 const introduced=introducedOnDate(active,now),target=dailyNewTarget(active,words.length,now);
 const dueIds=ids.filter(id=>active[id]?.dueAt<=now).sort((a,b)=>active[a].dueAt-active[b].dueAt);
 const freshIds=ids.filter(id=>!active[id]).slice(0,Math.max(0,target-introduced));
 const pendingIds=ids.filter(id=>mistakes[id]&&status(mistakes[id],now)==='pending');
 const nextDueAt=Object.values(active).filter(r=>r.dueAt>now).reduce<number|undefined>((n,r)=>n===undefined?r.dueAt:Math.min(n,r.dueAt),undefined);
 return {introduced,target,dueIds,freshIds,pendingIds,nextDueAt,tested:Object.keys(active).length,stage7:Object.values(active).filter(r=>r.level>=3).length,complete:!dueIds.length&&!freshIds.length&&!pendingIds.length};
}
export function sanitizeHistory(value:unknown):History {const out:History={};if(!value||typeof value!=='object')return out;for(const [id,indexes] of Object.entries(value))if(BY_ID.has(id)&&Array.isArray(indexes))out[id]=indexes.filter(x=>Number.isInteger(x)&&x>=0&&x<BY_ID.get(id)!.questions.length).slice(-20);return out;}
export function chooseQuestion(word:Word,wantChanged:boolean,history:readonly number[],last:number|undefined,random=Math.random) {
 const all=word.questions.map((_,i)=>i);const changed=(i:number)=>normalizeForm(word.questions[i].answer)!==normalizeForm(word.word);
 let pool=all.filter(i=>changed(i)===wantChanged);if(!pool.length)pool=all;
 let fresh=pool.filter(i=>!history.includes(i));if(!fresh.length)fresh=pool;
 const previous=last??history.at(-1);let candidates=fresh.filter(i=>i!==previous);
 if(!candidates.length)candidates=all.filter(i=>i!==previous);if(!candidates.length)candidates=all;
 return candidates[Math.floor(random()*candidates.length)];
}
export function createRound(kind:Kind,ids:readonly string[],words:readonly Word[],now:number,period:Period,history:History={},mistakes:Mistakes={},random=Math.random):Round|null {
 const allowed=new Set(words.map(w=>w.id));const targets=[...new Set(ids)].filter(id=>allowed.has(id)).slice(0,15);if(!targets.length)return null;
 const questionIds=different(targets,targets,random);let choices=[...targets];
 if(kind==='mistakes') {const confused=targets.flatMap(id=>mistakes[id]?.confusedWith??[]).filter(id=>allowed.has(id)&&!targets.includes(id));const others=shuffle(words.map(w=>w.id).filter(id=>!targets.includes(id)),random);choices=[...new Set([...choices,...confused,...others])].slice(0,targets.length+Math.min(6,Math.max(3,confused.length)));}
 if(choices.length<4)choices=[...choices,...shuffle(words.map(w=>w.id).filter(id=>!choices.includes(id)),random).slice(0,4-choices.length)];
 return {kind,period,questionIds,choiceIds:different(choices,questionIds,random),exampleIndexes:Object.fromEntries(questionIds.map((id,i)=>[id,chooseQuestion(BY_ID.get(id)!,i%2===0,history[id]??[],mistakes[id]?.lastExampleIndex,random)])),answers:{},formValues:{},hints:[],position:0,createdAt:now};
}
export function restoreRound(value:unknown):Round|null {
 if(!value||typeof value!=='object')return null;const raw=value as Partial<Round>;
 if(!['new','due','free','mistakes'].includes(raw.kind??'')||!Array.isArray(raw.questionIds)||!raw.questionIds.length||raw.questionIds.length>15||!Array.isArray(raw.choiceIds)||!Number.isFinite(raw.createdAt))return null;
 const questions=[...new Set(raw.questionIds)].filter(id=>BY_ID.has(id));const choices=[...new Set(raw.choiceIds)].filter(id=>BY_ID.has(id));
 if(questions.length!==raw.questionIds.length||!questions.every(id=>choices.includes(id)))return null;
 const period=questions.every(id=>BY_ID.get(id)!.list>=7)?'november':'october';
 const answers:Record<string,string>={},formValues:Record<string,string>={},used=new Set<string>();
 for(const id of questions){const selected=raw.answers?.[id];if(selected&&choices.includes(selected)&&!used.has(selected)){answers[id]=selected;used.add(selected);formValues[id]=typeof raw.formValues?.[id]==='string'?raw.formValues[id].slice(0,120):BY_ID.get(selected)!.word;}}
 return {kind:raw.kind as Kind,period,questionIds:questions,choiceIds:choices,answers,formValues,exampleIndexes:Object.fromEntries(questions.map(id=>{const n=raw.exampleIndexes?.[id];return[id,Number.isInteger(n)&&n!>=0&&n!<BY_ID.get(id)!.questions.length?n!:0];})),hints:Array.isArray(raw.hints)?raw.hints.filter(id=>questions.includes(id)):[],position:Math.max(0,Math.min(questions.length-1,Math.trunc(raw.position??0)||0)),createdAt:raw.createdAt!};
}
export function assignChoice(round:Round,selectedId:string):Round {
 if(!round.choiceIds.includes(selectedId)||!BY_ID.has(selectedId))return round;
 const target=round.questionIds[round.position];
 const owner=Object.entries(round.answers).find(([,id])=>id===selectedId)?.[0];
 if(owner&&owner!==target)return {...round,position:round.questionIds.indexOf(owner)};
 // Re-tapping an already selected family must retain the student's edited form.
 if(round.answers[target]===selectedId)return round;
 return {...round,answers:{...round.answers,[target]:selectedId},formValues:{...round.formValues,[target]:BY_ID.get(selectedId)!.word}};
}
export function evaluateRound(round:Round,records:ReviewState,mistakes:Mistakes,history:History,now:number) {
 if(!round.questionIds.every(id=>round.choiceIds.includes(round.answers[id])&&normalizeForm(round.formValues[id]??'').length)||new Set(Object.values(round.answers)).size!==round.questionIds.length)return null;
 const nextRecords={...records},nextMistakes={...mistakes},nextHistory={...history};
 const results=round.questionIds.map(targetId=>{
  const word=BY_ID.get(targetId)!,q=word.questions[round.exampleIndexes[targetId]],selectedId=round.answers[targetId],input=round.formValues[targetId];
  const wordCorrect=selectedId===targetId,formCorrect=wordCorrect&&isCorrectForm(q,input),correct=wordCorrect&&formCorrect,assisted=round.hints.includes(targetId);
  const reason:Result['reason']=!wordCorrect?'word':!formCorrect?'form':assisted?'hint':'correct';const outcome=correct?(assisted?'hint':'correct'):'wrong';
  let nextReview=round.kind==='free'?'自由练习：每日目标和复习日期不变。':'完成今日新词检测后安排复习。';
  if(round.kind!=='free'&&(round.kind!=='mistakes'||records[targetId])){const scheduled=scheduleReview(records[targetId],now,outcome);nextRecords[targetId]=scheduled.record;nextReview=scheduled.nextReview;}
  const previous=mistakes[targetId];
  if(reason==='correct'){if(previous)nextMistakes[targetId]={...previous,lastCorrectAt:now,lastExampleIndex:round.exampleIndexes[targetId],resolved:previous.resolved||beijingDateKey(previous.lastMissAt)!==beijingDateKey(now)};}
  else nextMistakes[targetId]={confusedWith:[...new Set([...(previous?.confusedWith??[]),...(!wordCorrect?[selectedId]:[])])],lastMissAt:now,resolved:false,lastExampleIndex:round.exampleIndexes[targetId],reason,lastInput:input,expected:q.answer};
  nextHistory[targetId]=[...(history[targetId]??[]),round.exampleIndexes[targetId]].slice(-20);
  return {targetId,selectedId,input,expected:q.answer,wordCorrect,formCorrect,correct,assisted,reason,nextReview};
 });
 return {records:nextRecords,mistakes:nextMistakes,history:nextHistory,report:{round,results,submittedAt:now} as Report};
}
