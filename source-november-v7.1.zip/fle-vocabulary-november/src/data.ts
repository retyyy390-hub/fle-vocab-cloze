import november from './november-data.json' with {type:'json'};
import legacy from './legacy-data.json' with {type:'json'};

export type Question = {text:string;answer:string;assistance:string;formLabel:string;source:string;accepted?:string[]};
export type Word = {id:string;word:string;list:number;pos:string;meaning:string;chinese?:string;sourceDefinition?:string;sourceFile?:string;note?:string;forms:string[];questions:Question[];examples:string[];paraphrases:string[]};
export type Period = 'november' | 'october';
export const PERIODS = {november:{label:'11月 · Lists 7–11',lists:[7,8,9,10,11]},october:{label:'10月 · Lists 4–6',lists:[4,5,6]}};
export const NOVEMBER = november as Word[];
const legacyWords = legacy.words.map(item => ({...item,forms:[item.word],sourceDefinition:legacy.definitions[item.id as keyof typeof legacy.definitions]?.join('\n') ?? item.meaning,questions:item.examples.map((text,index)=>({text,answer:item.word,assistance:item.paraphrases[index],formLabel:'使用词表中的形式',source:'本站练习'}))})) as Word[];
export const ALL_WORDS:Word[] = [...legacyWords,...NOVEMBER];
export const BY_ID = new Map(ALL_WORDS.map(word=>[word.id,word]));
export const VALID_IDS = new Set(BY_ID.keys());
export function wordsFor(period:Period) { return ALL_WORDS.filter(word=>PERIODS[period].lists.includes(word.list)); }
export const EXPORT_WORDS = NOVEMBER.map(word=>word.word).join('\n');

export function normalizeForm(value:string) {
  return value.normalize('NFKC').toLocaleLowerCase('en').replace(/[‘’]/g,"'").replace(/[‐‑–—]/g,'-').replace(/\s+/g,' ').trim();
}
const SPELLING_GROUPS = [
 ['tantalise','tantalize'],['tantalises','tantalizes'],['tantalised','tantalized'],['tantalising','tantalizing'],['tantalisingly','tantalizingly'],
 ['clamour','clamor'],['clamours','clamors'],['clamoured','clamored'],['clamouring','clamoring'],
 ['spiralled','spiraled'],['spiralling','spiraling'],['disorientating','disorienting'],['disorientated','disoriented'],['disorientate','disorient'],['disorientates','disorients'],['eyeing up','eying up'],
];
export function acceptedForms(question:Question) {
  const answers=new Set([question.answer,...question.accepted??[]].map(normalizeForm));
  for(const group of SPELLING_GROUPS) if(group.some(value=>answers.has(value))) group.forEach(value=>answers.add(value));
  if(question.answer==='busted') answers.add('bust');
  return [...answers];
}
export function isCorrectForm(question:Question,value:string) {return acceptedForms(question).includes(normalizeForm(value));}

// Some source examples allow both a noun and a gerund without changing meaning.
for(const word of NOVEMBER) for(const q of word.questions) {
 if(q.text==='We woke to the ____ of distant bells.') q.accepted=['chime','chimes','chiming'];
 if(q.text==='____ helps me relax in the evening.') q.accepted=['crochet','crocheting'];
}
