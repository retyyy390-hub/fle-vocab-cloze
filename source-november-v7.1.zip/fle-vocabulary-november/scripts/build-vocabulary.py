from pathlib import Path
import json, re, xml.etree.ElementTree as ET, zipfile

ROOT = Path(__file__).resolve().parents[1]
UPLOAD = ROOT.parent / 'upload'
FORMS = {
 'chime':'chime|chimes|chimed|chiming', 'muffle':'muffle|muffles|muffled|muffling|muffler|mufflers',
 'spooky':'spooky|spookier|spookiest|spookily|spook|spooks|spooked|spooking',
 'slime':'slime|slimy|slimier|slimiest|sliminess', 'blister':'blister|blisters|blistered|blistering',
 'leviathan':'leviathan|leviathans', 'cocoon':'cocoon|cocoons|cocooned|cocooning',
 'deplete':'deplete|depletes|depleted|depleting|depletion', 'unwavering':'unwavering|unwaveringly|waver|wavers|wavered|wavering',
 'ditch':'ditch|ditches|ditched|ditching', 'spindly':'spindly|spindlier|spindliest', 'paltry':'paltry',
 'artery':'artery|arteries|arterial', 'dwindle':'dwindle|dwindles|dwindled|dwindling',
 'hack':'hack|hacks|hacked|hacking|hacker|hackers',
 'glutinous':'glutinous|more glutinous|most glutinous|glutinously|glutinousness',
 'featureless':'featureless|featurelessly|featurelessness|feature|features|featured|featuring',
 'buzz':'buzz|buzzes|buzzed|buzzing|buzzer|buzzers|buzzword|buzzwords',
 'plunge':'plunge|plunges|plunged|plunging', 'squash':'squash|squashes|squashed|squashing',
 'tantalise':'tantalise|tantalises|tantalised|tantalising|tantalisingly|tantalize|tantalizes|tantalized|tantalizing|tantalizingly',
 'eye up':'eye up|eyes up|eyed up|eyeing up|eying up',
 'relinquish':'relinquish|relinquishes|relinquished|relinquishing|relinquishment',
 'demolish':'demolish|demolishes|demolished|demolishing|demolition',
 'perch':'perch|perches|perched|perching', 'precarious':'precarious|more precarious|most precarious|precariously|precariousness',
 'scoff':'scoff|scoffs|scoffed|scoffing', 'dismiss':'dismiss|dismisses|dismissed|dismissing|dismissal|dismissive|dismissively',
 'trinket':'trinket|trinkets', 'dab':'dab|dabs|dabbed|dabbing',
 'gape at':'gape at|gapes at|gaped at|gaping at', 'headlong':'headlong', 'virtually':'virtually|virtual',
 'impish':'impish|more impish|most impish|impishly|impishness|imp',
 'clamour':'clamour|clamours|clamoured|clamouring|clamor|clamors|clamored|clamoring',
 'thump':'thump|thumps|thumped|thumping', 'declaim':'declaim|declaims|declaimed|declaiming|declamation|declamatory',
 'gamely':'gamely', 'nudge':'nudge|nudges|nudged|nudging', 'prelude':'prelude|preludes|preluded|preluding',
 'hammer and tongs':'hammer and tongs', 'reverberate':'reverberate|reverberates|reverberated|reverberating|reverberation|reverberations',
 'brace':'brace|braces|braced|bracing', 'cowed':'cowed|cow|cows|cowing',
 'humble':'humble|humbles|humbled|humbling|humbler|humblest|humbly|humility',
 'dictate':'dictate|dictates|dictated|dictating|dictation|dictator|dictators', 'garment':'garment|garments',
 'feckless':'feckless|more feckless|most feckless|fecklessly|fecklessness',
 'crochet':'crochet|crochets|crocheted|crocheting', 'nag':'nag|nags|nagged|nagging',
 'smudge':'smudge|smudges|smudged|smudging',
 'spiral':'spiral|spirals|spiralled|spiralling|spiraled|spiraling',
 'maniacal':'maniacal|more maniacal|most maniacal|maniacally',
 'gyrate':'gyrate|gyrates|gyrated|gyrating|gyration|gyrations',
 'swirling':'swirling|swirl|swirls|swirled',
 'obstinate':'obstinate|more obstinate|most obstinate|obstinately|obstinacy',
 'adamant':'adamant|more adamant|adamantly', 'grit':'grit|gritty',
 'disorientating':'disorientating|disorienting|disorient|disorients|disoriented|disorientation|disorientate|disorientates|disorientated',
 'solitary':'solitary|solitarily|solitude', 'retrieve':'retrieve|retrieves|retrieved|retrieving|retrieval',
 'gimmick':'gimmick|gimmicks|gimmicky', 'seduce':'seduce|seduces|seduced|seducing|seductive|seductively|seduction',
 'carcass':'carcass|carcasses', 'hiss':'hiss|hisses|hissed|hissing', 'dome':'dome|domes|domed',
 'propel':'propel|propels|propelled|propelling|propulsion', 'bob':'bob|bobs|bobbed|bobbing',
 'bust':'bust|busts|busted|busting', 'slew':'slew',
 'seclude':'seclude|secludes|secluded|secluding|seclusion', 'prowl':'prowl|prowls|prowled|prowling|prowler|prowlers',
 'excerpt':'excerpt|excerpts|excerpted|excerpting', 'forage':'forage|forages|foraged|foraging',
 'endearing':'endearing|more endearing|most endearing|endearingly|endear|endears|endeared',
}
ZH = ['钟鸣；一致','使声音变闷；裹住','阴森的','黏液','水疱；使起疱','庞然大物','茧；包裹保护','耗尽','坚定不移的','沟渠；抛弃','细长而脆弱的','少得可怜的','动脉；干线','逐渐减少','劈砍；入侵；应付', '黏稠的','没有特征的','嗡嗡声；兴奋','骤降；跳入','压扁；壁球；南瓜','使心痒难耐','饶有兴趣地打量','放弃','拆毁；大胜；吃光','栖息；栖木','不稳的；危险的','嘲笑','不予考虑；解雇','廉价小饰物','轻拍；少量', '张口惊看','鲁莽地；仓促的','几乎；以虚拟方式','顽皮的','喧嚷；强烈要求','重击；怦怦跳','慷慨激昂地朗诵','勇敢而不抱怨地','轻推；劝说','前奏；序幕','猛烈地；全力以赴地','回响；持续产生影响','支撑；准备应对','被吓住的','谦逊的；使认识到不足', '口述；决定','衣物','无能而不负责任的','钩针编织','唠叨；纠缠','污痕；弄花','螺旋；盘旋','疯狂的','旋转','打旋的','固执的','坚决的','毅力；沙砾','使迷失方向的','独自的', '取回；检索','噱头','诱使','动物尸体','嘶嘶声；低声怒斥','穹顶','推动','上下轻动；波波头','打碎；突袭；半身像；破产','大量','使隔离','潜行','节选','觅食；饲料','惹人喜爱的']
NOTES = {
 'muffle':'muffled 通常描述声音闷住、不清晰。空气不流通宜用 stuffy；原材料中的 muffled air 不作为测试用法。',
 'glutinous':'glutinous 表示黏稠、胶状；不能据此判断食物含有 gluten（麸质）。',
 'unwavering':'waver 是“动摇”，unwavering 是“不动摇”。注意否定前缀会改变词义。',
 'spindly':'词形测试使用常见形容词及比较级；spindle 是相关词，不作为本组必考词形。',
 'paltry':'主要掌握 paltry；不为凑词形而考罕见的比较级。',
 'artery':'artery 的复数为 arteries，形容词为 arterial。动脉按血液流动方向定义，不按血液颜色定义。',
 'tantalise':'接受英式 tantalise / tantalising 和美式 tantalize / tantalizing。',
 'eye up':'保留 up：eye up → eyes up → eyed up → eyeing up。',
 'gape at':'保留 at：gape at → gapes at → gaped at → gaping at。',
 'hammer and tongs':'固定短语，保持 hammer and tongs 的顺序与 tongs 的复数形式。变化的是句中的主语和谓语。',
 'cowed':'本组 cow 作动词时表示“威吓”；不要把名词“奶牛”当成这个意思的派生形式。',
 'grit':'本组 grit（毅力／细沙）作不可数名词；不写 grits。gritty 是形容词。',
 'disorientating':'接受 disorientating / disorienting 等常用变体；结合句子区分“令人迷失”和“感到迷失”。',
 'spiral':'接受英式 spiralled / spiralling 和美式 spiraled / spiraling。',
 'slew':'重点搭配 a slew of，表示大量；不要在此搭配中把 slew 当作动词 slay 的过去式。',
 'squash':'原词表中“to forcefully an activity or argument”缺少动词；练习采用“压制、否定提议或反对意见”的用法。',
 'cocoon':'作动词的近义词应写 envelop（包裹）；原词表中的 envelope 通常是名词“信封”。',
}
POS = {'chime':'verb / noun','blister':'noun / verb','cocoon':'noun / verb','ditch':'noun / verb','hack':'verb / noun','buzz':'noun / verb','plunge':'verb / noun','squash':'verb / noun','perch':'verb / noun','scoff':'verb / noun','dab':'verb / noun','headlong':'adverb / adjective','clamour':'verb / noun','thump':'verb / noun','nudge':'verb / noun','prelude':'noun / verb','brace':'verb / noun','humble':'adjective / verb','crochet':'verb / noun','smudge':'noun / verb','spiral':'noun / verb','hiss':'verb / noun','bob':'verb / noun','bust':'verb / noun / adjective','prowl':'verb / noun','excerpt':'noun / verb','forage':'verb / noun'}

def load_words():
 ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
 words=[]; current=None; group=None
 for filename in ['0500_FLE_edition 6_Vocab 7-9.docx','0500_FLE_edition 6_Vocab 10-11.docx']:
  with zipfile.ZipFile(UPLOAD/filename) as z: tree=ET.fromstring(z.read('word/document.xml'))
  for p in tree.findall('.//w:p',ns):
   line=''.join(n.text or '' for n in p.findall('.//w:t',ns)).strip()
   if not line: continue
   m=re.fullmatch(r'List (\d+)',line)
   if m: group=int(m[1]); continue
   match=next((w for w in FORMS if line.lower().startswith(w+' ') or line.lower().startswith(w+'\xa0')),None)
   if match:
    definition=line[len(match):].strip()
    pos={'V.':'verb','N.':'noun','A.':'adjective','Adv.':'adverb','PV':'phrasal verb','IDIOM':'idiom'}.get(definition.split()[0],'word')
    current={'id':'nov-'+match.replace(' ','-'),'word':match,'list':group,'pos':pos,'meaning':definition,'sourceDefinition':definition,'forms':FORMS[match].split('|'),'note':NOTES.get(match,''),'sourceFile':filename,'questions':[]}
    words.append(current)
   elif current: current['sourceDefinition']+='\n'+line
 assert len(words)==75 and [w['word'] for w in words]==list(FORMS)
 for i,w in enumerate(words): w['chinese']=ZH[i]; w['meaning']=w['sourceDefinition']; w['pos']=POS.get(w['word'],w['pos'])
 return words

def source_questions(words):
 files=json.loads((ROOT.parent/'extracted/tables.json').read_text())
 for file in files:
  group=int(re.search(r'List (\d+)',file['file']).group(1))
  entries=[w for w in words if w['list']==group]
  for w,page in zip(entries,file['pages']):
   if not page['tables']: continue
   for label,sample,*_ in page['tables'][0][1:]:
    label=' '.join((label or '').split()); sample=' '.join((sample or '').split())
    if re.match(r'(Comparison|Collocations?|Synonyms|Pattern|Position|US spelling|Uncountable|Fixed)',label,re.I) or sample.startswith('Rare.'): continue
    if w['word']=='artery' and 'bright red' in sample: continue
    if w['word']=='cowed' and 'milk' in sample: continue
    if w['word']=='muffle' and ';' in sample: sample=sample.split(';')[0]+'.'
    for sentence in re.split(r';\s*',sample):
     if not re.search(r'[.!?][\'\"]?$',sentence): continue
     forms=sorted(w['forms'],key=len,reverse=True)
     pattern=r'(?<![\w-])(?:'+'|'.join(re.escape(v) for v in forms)+r')(?![\w-])'
     matches=list(re.finditer(pattern,sentence,re.I))
     if len(matches)!=1: continue
     m=matches[0]; answer=m.group(0).lower()
     text=sentence[:m.start()]+'____'+sentence[m.end():]
     meaning=w['chinese']
     w['questions'].append({'text':text,'answer':answer,'assistance':'本句考查：'+meaning+'。结合句子中的主语、时间或词性选择形式。','source':'课堂词形材料','formLabel':label})
 return words

if __name__=='__main__':
 words=source_questions(load_words())
 extra_file=ROOT/'src/november-contexts.json'
 extra=json.loads(extra_file.read_text()) if extra_file.exists() else {}
 for w in words:
  for row in extra.get(w['word'],[]):
   answer,text,assistance,*label=row
   assert answer in w['forms'],(w['word'],answer)
   assert text.count('____')==1,(w['word'],text)
   w['questions'].append({'text':text,'answer':answer,'assistance':assistance,'source':'本站练习','formLabel':label[0] if label else '根据语境使用 '+answer})
  # Keep the source order stable; duplicate templates never produce two test items.
  seen=set(); w['questions']=[q for q in w['questions'] if not(q['text'] in seen or seen.add(q['text']))]
  w['examples']=[q['text'] for q in w['questions']]; w['paraphrases']=[q['assistance'] for q in w['questions']]
 (ROOT/'src/november-data.json').write_text(json.dumps(words,ensure_ascii=False,indent=2)+'\n')
 print('WORDS',len(words),'QUESTIONS',sum(len(w['questions']) for w in words))
 print('NEED TO REACH TEN',[(w['word'],len(w['questions'])) for w in words if len(w['questions'])<10])
