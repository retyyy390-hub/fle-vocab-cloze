import {readFile,writeFile,readdir,rm} from 'node:fs/promises';
import {createHash} from 'node:crypto';
let html=await readFile('dist/index.html','utf8');
for(const file of await readdir('dist/assets')) {
 const data=await readFile('dist/assets/'+file,'utf8');
 if(file.endsWith('.js'))html=html.replace(new RegExp('<script[^>]+src="[^"]*'+file+'"[^>]*></script>'),()=>'<script type="module">'+data.replaceAll('</script','<\\/script')+'</script>');
 if(file.endsWith('.css'))html=html.replace(new RegExp('<link[^>]+href="[^"]*'+file+'"[^>]*>'),()=>'<style>'+data.replaceAll('</style','<\\/style')+'</style>');
}
await writeFile('dist/index.html',html);await rm('dist/assets',{recursive:true});
const version=createHash('sha256').update(html).digest('hex').slice(0,12);let worker=await readFile('public/sw.js','utf8');worker=worker.replace(/const CACHE_NAME\s*=\s*[^;]+;/,'const CACHE_NAME = "fle-vocab-pwa-'+version+'";');await writeFile('dist/sw.js',worker);
console.log('Inline build',Buffer.byteLength(html),'bytes; cache',version);
