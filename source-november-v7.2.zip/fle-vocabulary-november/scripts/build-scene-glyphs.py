"""Build the site's original, offline SVG objects used in sentence illustrations."""
from pathlib import Path
import json
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
B, G, Y, R, P, W = '#97bbc9', '#96b394', '#e6c486', '#cd9286', '#b5a3bf', '#f9f6ed'
GLYPHS = {}

def put(name, art):
    GLYPHS[name] = art

def person(color=B, mood='calm', pose='standing', child=False):
    mouth = {'calm':'M42 32Q49 36 56 32','happy':'M40 29Q49 43 59 29','worried':'M41 36Q49 28 57 36','angry':'M40 36L58 34'}[mood]
    legs = 'M42 71L35 94M57 71L65 94' if pose=='standing' else 'M42 71L21 77 12 90M57 71L77 59 91 74' if pose=='running' else 'M42 71H70V92M57 71H78V92'
    arms = 'M36 50L22 65M63 50L78 65' if pose!='running' else 'M36 50L19 37 11 46M63 50L77 62 88 51'
    art=f'<circle cx="49" cy="23" r="17" fill="#ebc5a4"/><path d="M33 19Q33 2 49 6Q68 3 66 20" fill="#806f5d"/><path d="M41 23h1M56 23h1"/>'
    art+=f'<path d="{mouth}"/><path d="M35 44H64L69 72H30Z" fill="{color}"/><path d="{arms} {legs}" stroke-width="4"/>'
    return '<g transform="translate(10 14) scale(.8)">'+art+'</g>' if child else art

def face(mood):
    eyes='M29 37L40 42M61 42L72 37' if mood=='angry' else 'M30 39h4M65 39h4'
    mouth={'happy':'M29 55Q50 83 72 55','worried':'M32 70Q50 53 69 70','angry':'M31 69L69 64'}[mood]
    return f'<circle cx="50" cy="50" r="38" fill="#ebc5a4"/><path d="{eyes}" stroke-width="4"/><path d="{mouth}"/>'

def animal(species):
    dead=species=='animal-body'; tall=species in ['horse','donkey','deer']
    color={'fox':'#d3a073','lion':'#d9b86f','cat':'#c5b8a5','deer':'#b89572','dog':'#bba17c','horse':'#ad947c','donkey':'#b3ada1','squirrel':'#bf9973','animal-body':'#c4bbb0'}.get(species,B)
    body=f'<ellipse cx="46" cy="61" rx="29" ry="18" fill="{color}"/>'
    body+=f'<path d="M23 62L18 88M39 66L37 89M57 65L61 88M66 59L76 86" stroke-width="5"/>' if not dead else '<path d="M24 70L18 81M45 74L40 84M60 70L69 78"/>'
    heady=29 if tall else 43
    if species=='lion':body+=f'<circle cx="75" cy="{heady+4}" r="24" fill="#a88b65"/>'
    body+=f'<path d="M65 54L67 {heady}L80 {heady-7}L91 {heady+2}L93 {heady+17}L78 {heady+21}L68 57Z" fill="{color}"/>'
    body+=f'<path d="M71 {heady-2}L67 {heady-17}L78 {heady-6}M80 {heady-5}L84 {heady-17}L86 {heady+1}" fill="{color}"/>'
    body+='<path d="M79 40l6 5m-6 0l6-5"/>' if dead else f'<circle cx="81" cy="{heady+6}" r="1.5" fill="#35546c"/>'
    body+=f'<path d="M18 57Q-2 29 11 24Q32 23 23 50" fill="{color}"/>' if species in ['fox','squirrel'] else '<path d="M19 51Q5 40 9 30"/>'
    if species=='deer':body+='<path d="M71 21L65 9M66 13L58 10M82 19L88 7M86 11L94 9"/>'
    if species=='cat':body+='<path d="M89 48L99 45M89 51L99 53"/>'
    if dead:body='<g transform="rotate(12 50 65)">'+body+'</g>'
    return body

put('person',person());put('child',person(Y,'happy',child=True));put('runner',person(G,pose='running'));put('seated-person',person(P,pose='seated'))
put('face-smile',face('happy'));put('face-worried',face('worried'));put('face-angry',face('angry'))
put('group','<g transform="translate(-5 9) scale(.64)">'+person(G)+'</g><g transform="translate(42 9) scale(.64)">'+person(P)+'</g>')
put('hand','<path d="M28 82L18 60Q15 50 22 49L34 58V24Q34 16 41 23V47V16Q44 9 49 17V47V21Q54 14 58 23V48V30Q65 23 68 33L72 64Q69 87 55 91H39Z" fill="#ebc5a4"/>')
put('eyes','<path d="M6 49Q25 19 45 49Q26 77 6 49ZM54 49Q74 19 94 49Q74 77 54 49Z" fill="white"/><circle cx="30" cy="49" r="9" fill="'+B+'"/><circle cx="78" cy="49" r="9" fill="'+B+'"/>')
put('bell','<path d="M22 72Q31 61 31 37Q32 17 50 17Q69 17 70 37Q70 61 79 72Z" fill="'+Y+'"/><path d="M16 73H85M43 80Q50 94 58 80M46 16V9H55V16"/>')
put('clock','<circle cx="50" cy="50" r="37" fill="'+W+'"/><path d="M50 17V24M50 76V83M17 50H24M76 50H83M50 30V51L65 61"/><circle cx="50" cy="50" r="3" fill="'+B+'"/>')
put('speaker','<path d="M13 38H32L57 17V84L32 63H13Z" fill="'+B+'"/><path d="M69 34Q88 50 69 66M78 23Q105 50 78 77"/>')
put('scarf','<path d="M22 21Q50 4 78 21V42Q50 58 22 42ZM36 48L30 87H50L55 50M61 47L66 81H84L76 41" fill="'+P+'"/><path d="M31 79H50M66 73H82M32 87V94M40 87V94M48 87V94"/>')
put('pillow','<path d="M17 28Q49 35 83 28L78 73Q50 65 22 73Z" fill="'+W+'"/><path d="M21 36Q50 43 79 36M28 44L24 66M72 44L76 66" stroke="#bcc9cf"/>')
put('snowflake','<path d="M50 9V91M15 29L85 71M15 71L85 29M39 16L50 27 61 16M39 84L50 73 61 84M18 42L32 39 32 23M68 77V61L82 58M18 58L32 61V77M68 23V39L82 42" stroke="#7aabbf"/>')
put('wall','<path d="M10 22H90V82H10Z" fill="#d6c9b5"/><path d="M10 42H90M10 62H90M30 22V42M68 22V42M49 42V62M30 62V82M69 62V82"/>')
put('curtain','<path d="M10 14H90M17 19H83V91H17Z" fill="#d8e3e5"/><path d="M17 19H45Q48 57 30 66L42 91H17ZM83 19H55Q52 57 70 66L58 91H83Z" fill="'+P+'"/><path d="M23 24L26 59M77 24L74 59M24 66H34M66 66H76"/>')
put('house','<path d="M8 44L50 12 92 44Z" fill="'+R+'"/><path d="M18 44H82V91H18Z" fill="'+Y+'"/><path d="M43 91V63H59V91M27 53H37V66H27ZM65 53H75V66H65Z" fill="'+W+'"/>')
put('book','<path d="M10 22Q30 13 50 24Q70 13 90 22V81Q70 73 50 85Q30 73 10 81Z" fill="'+W+'"/><path d="M50 24V85M20 33L41 35M20 45L41 47M60 35L80 33M60 47L80 45M20 59L39 61M61 61L80 59"/>')
put('ghost','<path d="M20 87V39Q20 10 50 10Q80 10 80 39V87L69 78 59 87 49 78 39 87 29 78Z" fill="'+W+'"/><ellipse cx="39" cy="41" rx="4" ry="7" fill="#5b7180"/><ellipse cx="62" cy="41" rx="4" ry="7" fill="#5b7180"/><ellipse cx="50" cy="62" rx="6" ry="9"/>')
put('playground','<path d="M12 90L33 16H70L91 90M28 28H75M42 22V65M63 22V65"/><path d="M37 66H69V72H37Z" fill="'+R+'"/><path d="M19 90H84" stroke="#a5b797"/>')
put('snail','<path d="M12 76H78Q94 74 91 57L86 51 80 58 73 69H12Z" fill="'+G+'"/><circle cx="42" cy="54" r="23" fill="'+Y+'"/><path d="M43 66Q25 61 33 46Q43 34 54 48Q60 62 43 60Q36 56 44 52M82 58L79 42M88 57L93 41"/><circle cx="79" cy="41" r="2"/><circle cx="93" cy="40" r="2"/>')
put('rock','<path d="M12 78L23 38 50 19 79 32 91 77 62 87Z" fill="#adb9b7"/><path d="M24 39L49 49 50 19M49 49L62 87M49 49L79 32" stroke="#829995"/><path d="M24 41Q50 32 77 40" stroke="'+G+'" stroke-width="8"/>')
put('pond','<ellipse cx="50" cy="64" rx="43" ry="24" fill="#b4d0d4"/><ellipse cx="42" cy="61" rx="26" ry="11" fill="none" stroke="#7ea7ad"/><path d="M15 58V29M10 40L15 45 23 35M83 63V34" stroke="#71936e"/><ellipse cx="70" cy="58" rx="10" ry="5" fill="'+G+'"/>')
put('egg','<path d="M25 65Q18 37 39 15Q50 4 62 18Q83 44 75 67Q64 90 42 84Q26 81 25 65Z" fill="#f3e6cd"/><path d="M36 37Q38 27 44 24" stroke="white" stroke-width="5"/>')
put('vegetables','<path d="M14 57Q24 35 39 57Q48 26 62 51Q88 35 91 67L80 86H24Z" fill="'+G+'"/><path d="M45 54L59 90 75 51Z" fill="#d6a16c"/><path d="M58 54L56 38M62 55L73 37M53 68L62 66"/>')
put('shoe','<path d="M17 43L42 38Q43 59 64 63L85 65Q96 77 87 83H14V68Z" fill="'+B+'"/><path d="M15 76H91M45 51L37 56M51 58L44 62M55 64L49 69"/><ellipse cx="25" cy="52" rx="5" ry="4" fill="'+R+'"/>')
put('paint','<path d="M17 36H71V88H17Z" fill="'+B+'"/><ellipse cx="44" cy="36" rx="27" ry="8" fill="'+W+'"/><path d="M24 36Q18 8 44 8Q69 8 64 36M25 42V58Q31 67 36 57V44"/><path d="M76 13L87 18 66 62 57 57Z" fill="'+Y+'"/><path d="M57 58L67 63Q63 82 50 74Z" fill="'+R+'"/>')
put('fence','<path d="M10 41H92V51H10ZM10 66H92V76H10Z" fill="'+Y+'"/><path d="M15 87V22L23 12 31 22V87M45 87V22L53 12 61 22V87M75 87V22L83 12 91 22V87" fill="#c4a484"/>')
put('sun','<circle cx="50" cy="50" r="24" fill="'+Y+'"/><path d="M50 6V18M50 82V94M6 50H18M82 50H94M18 18L26 26M74 74L82 82M18 82L26 74M74 26L82 18" stroke="#c89f61"/>')
put('ship','<path d="M8 63H93L80 86H25Z" fill="'+B+'"/><path d="M30 63V43H62V63M39 43V25H53V43M63 52H80V63" fill="'+W+'"/><path d="M8 91Q22 85 35 91T61 91T94 91M34 53H39M48 53H53M44 25V12"/>')
put('office','<path d="M20 89V17H63V89M63 41H83V89" fill="'+B+'"/><path d="M30 29H38V38H30ZM46 29H54V38H46ZM30 48H38V57H30ZM46 48H54V57H46ZM30 67H38V76H30ZM46 67H54V76H46ZM69 51H76M69 63H76M69 75H76" fill="'+W+'"/>')
put('sea-monster','<path d="M7 73Q16 49 33 69Q41 81 47 62Q52 39 61 53Q67 61 69 35L81 19 93 28 86 42Q93 82 65 82Q40 95 7 80Z" fill="'+G+'"/><path d="M72 30L80 24M82 40L89 42M19 69L23 56 30 66M44 68L49 52"/><circle cx="84" cy="29" r="2"/>')
put('cocoon','<path d="M9 16Q50 30 93 13M50 23V37" stroke="#8b7558"/><path d="M50 36Q72 45 65 76Q60 94 45 89Q28 82 34 57Q38 42 50 36Z" fill="'+Y+'"/><path d="M37 52L66 60M34 63L66 71M38 76L61 83M41 44L62 49" stroke="#b29b76"/>')
put('bed','<path d="M8 90V36H17V59H91V90M17 80H91" fill="'+Y+'"/><path d="M18 56Q23 32 47 54H86V72H18Z" fill="'+B+'"/><rect x="21" y="45" width="25" height="14" rx="5" fill="'+W+'"/>')
put('baby','<path d="M25 49Q50 25 75 49L65 84Q50 100 35 84Z" fill="'+B+'"/><circle cx="50" cy="33" r="19" fill="#ebc5a4"/><path d="M42 30H43M57 30H58M45 41Q50 44 55 41M27 51L65 80M73 51L35 82"/>')
put('fish','<path d="M20 52Q45 17 76 49L94 33V70L76 56Q45 90 20 52Z" fill="'+B+'"/><path d="M43 27L58 15 61 31M41 77L57 88 62 70" fill="'+G+'"/><circle cx="35" cy="48" r="3" fill="#35546c"/>')
put('mountain','<path d="M6 86L42 15 62 46 75 28 95 86Z" fill="#9dafb6"/><path d="M29 42L42 15 57 42 44 34Z" fill="'+W+'"/><path d="M20 87H91"/>')
put('fuel','<path d="M13 87V23Q13 17 21 17H61Q68 17 68 25V87Z" fill="'+B+'"/><rect x="23" y="28" width="33" height="25" rx="3" fill="'+W+'"/><path d="M68 35Q88 35 82 63Q82 77 92 74V31L83 21M9 88H73"/><path d="M29 69H54" stroke="'+Y+'" stroke-width="6"/>')
put('reservoir','<path d="M10 28H89V86H10Z" fill="'+W+'"/><path d="M10 61Q25 55 39 61T67 61T89 61V86H10Z" fill="'+B+'"/><path d="M11 27L25 11H75L89 27M32 38H69M25 73H70" stroke="#88a3ac"/>')
put('coins','<ellipse cx="33" cy="74" rx="23" ry="8" fill="'+Y+'"/><path d="M10 65V74Q33 86 56 74V65M10 54V65Q33 77 56 65V54M10 43V54Q33 66 56 54V43" fill="'+Y+'"/><ellipse cx="33" cy="43" rx="23" ry="8" fill="'+Y+'"/><circle cx="73" cy="68" r="19" fill="'+Y+'"/><path d="M73 57V79M67 60H77M67 75H77"/>')
put('plant','<path d="M24 74H77L70 94H31Z" fill="'+R+'"/><path d="M50 75V20M50 54Q20 54 20 29Q45 28 50 49M50 39Q53 12 79 16Q78 41 50 39" fill="'+G+'"/>')
put('tree','<path d="M47 87V55H55V87Z" fill="#b29b7d"/><path d="M49 6L19 50H32L10 70H88L67 50H79Z" fill="'+G+'"/>')
put('chair','<path d="M24 55V15H75V55M21 58H80V67H21ZM28 67L22 93M71 67L79 93M30 26H68M30 38H68" fill="'+Y+'"/>')
put('meal','<ellipse cx="50" cy="62" rx="36" ry="21" fill="'+W+'"/><ellipse cx="50" cy="62" rx="26" ry="13" fill="'+Y+'"/><path d="M35 58Q40 39 50 54Q67 42 72 64" fill="'+G+'"/><path d="M6 27V85M2 17V34H10V17M95 17V84"/><circle cx="56" cy="62" r="7" fill="'+R+'"/>')
put('stadium','<path d="M7 51Q50 10 93 51V79Q50 99 7 79Z" fill="'+B+'"/><ellipse cx="50" cy="61" rx="37" ry="19" fill="'+G+'"/><ellipse cx="50" cy="61" rx="25" ry="11" fill="none" stroke="'+W+'"/><path d="M50 50V72M15 32V16H26L15 25M84 32V16H95L84 25"/>')
put('artery','<path d="M50 38Q29 14 19 34Q8 54 50 87Q91 54 81 34Q71 14 50 38Z" fill="'+R+'"/><path d="M49 49V11L36 5M49 20L67 8M49 55L30 59 18 49M56 58L73 65 88 57" stroke="#b86f65" stroke-width="7"/><path d="M43 17L49 10 55 17M75 59L83 58 79 65" fill="none" stroke="'+W+'" stroke-width="2"/>')
put('road','<path d="M36 9H65L92 94H9Z" fill="#a7b5b9"/><path d="M50 17V29M50 39V54M50 65V83" stroke="'+W+'" stroke-width="4"/>')
put('train','<path d="M20 20Q50 4 80 20V72H20Z" fill="'+B+'"/><path d="M29 24H71V47H29Z" fill="'+W+'"/><circle cx="33" cy="60" r="4" fill="'+Y+'"/><circle cx="67" cy="60" r="4" fill="'+Y+'"/><path d="M32 73L19 94M68 73L81 94M22 87H78M50 26V47"/>')
put('box','<path d="M10 34L49 15 90 34V77L49 94 10 77Z" fill="'+Y+'"/><path d="M10 34L49 52 90 34M49 52V94M30 25L70 44V60"/>')
put('candle','<path d="M34 45H65V90H34Z" fill="'+Y+'"/><ellipse cx="50" cy="44" rx="15" ry="5" fill="'+W+'"/><path d="M50 37V28M50 29Q32 18 50 4Q68 22 50 29Z" fill="#dfaf6e"/><path d="M25 91H75"/>')
put('axe','<path d="M24 88L68 13" stroke="#a48664" stroke-width="10"/><path d="M52 19L74 11Q80 35 96 42L72 59 58 40Z" fill="#aebec2"/>')
put('laptop','<path d="M19 18H82V68H19Z" fill="'+B+'"/><path d="M27 26H74V58H27Z" fill="'+W+'"/><path d="M19 68L5 84H95L82 68Z" fill="#bac9cd"/><path d="M36 76H65M35 35H65M35 44H55"/>')
put('rice','<path d="M14 50H88Q83 88 51 89Q20 88 14 50Z" fill="'+B+'"/><path d="M16 50Q16 26 35 31Q47 16 58 31Q80 23 87 50Z" fill="'+W+'"/><path d="M27 38L30 43M42 33L45 38M56 36L61 40M72 39L75 44"/>')
put('dough','<path d="M15 68Q9 42 34 36Q45 16 65 34Q91 35 89 63Q89 85 49 86Q15 84 15 68Z" fill="'+Y+'"/><path d="M30 51Q50 39 69 53M32 65Q47 57 64 66" stroke="#b89b76"/>')
put('horizon','<path d="M5 61H95M12 76H89M26 89H76" stroke="#9ab5b8"/><path d="M27 59Q27 22 50 22Q74 22 74 59Z" fill="'+Y+'"/><path d="M12 46L19 48M82 46L90 43M50 5V13"/>')
put('phone','<rect x="28" y="7" width="46" height="87" rx="7" fill="'+B+'"/><rect x="34" y="20" width="34" height="57" rx="2" fill="'+W+'"/><path d="M43 13H57M45 86H56M41 36H62M41 47H57"/>')
put('bee','<ellipse cx="35" cy="31" rx="16" ry="21" transform="rotate(-25 35 31)" fill="#e1edf0"/><ellipse cx="64" cy="31" rx="16" ry="21" transform="rotate(25 64 31)" fill="#e1edf0"/><ellipse cx="50" cy="56" rx="33" ry="21" fill="'+Y+'"/><path d="M38 37V75M53 36V76M68 39V72" stroke-width="7"/><circle cx="22" cy="50" r="3" fill="#35546c"/><path d="M18 40L12 28M83 56L92 56"/>')
put('pool','<path d="M8 43L52 18 93 44 52 84Z" fill="#d8e2df"/><path d="M17 44L52 25 84 44 51 73Z" fill="'+B+'"/><path d="M33 43Q42 38 50 43T69 43M35 54Q44 49 52 54T68 54M73 22V53M83 27V56M73 34H83M73 43H83"/>')
put('chart','<rect x="13" y="14" width="75" height="67" rx="4" fill="'+W+'"/><path d="M25 26V68H78M31 59L45 46 57 54 75 32M66 33L75 32 77 42" stroke="#6f9b9b"/><path d="M49 81V94M32 94H68"/>')
put('racket','<ellipse cx="41" cy="36" rx="23" ry="29" transform="rotate(30 41 36)" fill="'+W+'"/><path d="M56 59L79 92" stroke="#9b846b" stroke-width="8"/><path d="M24 29L58 43M25 40L50 51M35 15L51 52M47 15L28 52" stroke="#90a8af" stroke-width="1.5"/><circle cx="83" cy="27" r="8" fill="'+Y+'"/>')
put('glass','<path d="M25 17H77L68 89H34Z" fill="#e4eff0"/><path d="M30 47H72L67 84H35Z" fill="'+Y+'"/><path d="M60 15L70 5"/>')
put('pumpkin','<path d="M16 43Q26 26 41 35Q52 24 64 35Q84 28 90 50Q100 83 66 88Q48 96 30 86Q4 80 16 43Z" fill="#d9a267"/><path d="M46 32L42 12 56 15 55 32M42 37Q26 66 42 88M61 37Q78 66 61 88M51 37V88"/>')
put('cake','<path d="M14 50L62 26 91 47V82H14Z" fill="'+Y+'"/><path d="M14 50L62 26 91 47 44 64Z" fill="#e7b1a2"/><path d="M14 68H43L91 53M44 64V82"/><circle cx="63" cy="24" r="7" fill="'+R+'"/>')
put('trophy','<path d="M29 13H72V45Q68 63 51 67Q33 62 29 45Z" fill="'+Y+'"/><path d="M29 23H13Q10 53 36 50M72 23H87Q90 53 65 50M51 67V82M35 84H67V92H35Z" fill="'+Y+'"/>')
put('film','<rect x="8" y="23" width="85" height="59" rx="5" fill="#a6b8c2"/><path d="M8 35H93M8 68H93M18 23V35M32 23V35M47 23V35M62 23V35M78 23V35M18 68V82M32 68V82M47 68V82M62 68V82M78 68V82"/><path d="M41 42L62 52 41 62Z" fill="'+W+'"/>')
put('bicycle','<circle cx="24" cy="68" r="18"/><circle cx="80" cy="68" r="18"/><path d="M24 68L41 39 60 68H24L36 30M41 39H69L80 68M69 39L66 24H78M30 30H44" stroke="#7298a2" stroke-width="3"/>')
put('crown','<path d="M13 31L30 49 50 14 70 49 88 31 81 81H20Z" fill="'+Y+'"/><path d="M20 69H82M33 56L40 62M60 62L67 56"/><circle cx="50" cy="56" r="6" fill="'+R+'"/>')
put('contract','<path d="M21 8H66L82 24V92H21Z" fill="'+W+'"/><path d="M65 8V26H82M32 37H69M32 49H69M32 61H54M44 78Q51 68 58 79T71 75"/><path d="M12 91L32 68 39 74 20 96Z" fill="'+Y+'"/>')
put('building','<path d="M13 88V31L39 12H82V88Z" fill="#bdc9c9"/><path d="M24 43H36V56H24ZM48 31H61V46H48ZM66 31H76V46H66ZM48 57H61V72H48ZM29 88V68H41V88M68 61H77V88" fill="'+W+'"/>')
put('hammer','<path d="M28 88L62 31" stroke="#a98d70" stroke-width="12"/><path d="M39 23L56 10 87 28 89 44 74 50 61 37 53 46Z" fill="#aabdc3"/>')
put('football','<circle cx="50" cy="50" r="37" fill="'+W+'"/><path d="M39 34L61 34 68 54 50 67 32 54ZM39 34L27 19M61 34L75 20M68 54L86 60M50 67V87M32 54L14 61" fill="'+B+'"/>')
put('bird','<path d="M14 65Q40 64 44 41Q44 20 62 23Q79 24 79 44L94 47 79 52Q75 79 47 75L26 83Z" fill="'+B+'"/><path d="M43 54Q51 39 64 50Q60 65 43 66M49 74L45 91M61 74L64 91M37 92H50M58 92H72"/><circle cx="68" cy="36" r="2" fill="#35546c"/>')
put('cliff','<path d="M5 24H70L66 41 78 63 65 74 74 96H5Z" fill="#b2b9a7"/><path d="M9 25H66M14 42L34 37 50 45M25 60L46 55 60 65M80 84Q86 79 95 84" stroke="#8ca5ab"/>')
put('vase','<path d="M39 10H62V30Q65 38 78 55Q91 88 52 92Q12 89 26 55Q39 37 39 30Z" fill="'+B+'"/><path d="M38 20H63M26 62Q50 73 79 62"/>')
put('ladder','<path d="M24 92L38 8M62 92L76 8M36 20H74M33 37H71M30 54H68M27 71H65M24 88H62" stroke="#ad9473" stroke-width="6"/>')
put('suitcase','<rect x="14" y="29" width="75" height="55" rx="7" fill="'+Y+'"/><path d="M39 29V16H65V29M31 30V83M73 30V83"/><circle cx="28" cy="90" r="4" fill="#35546c"/><circle cx="76" cy="90" r="4" fill="#35546c"/>')
put('speech','<path d="M9 15H90V67H53L31 88V67H9Z" fill="'+W+'"/><path d="M23 31H76M23 43H65M23 55H72" stroke="#90a8b1"/>')
put('classroom','<rect x="8" y="10" width="85" height="50" rx="3" fill="#8eaca3"/><path d="M21 26H65M21 38H76M16 69H46V89M56 69H86V89M24 69V89M64 69V89" stroke="'+W+'"/><path d="M14 64V92M90 64V92"/>')
put('trinket','<path d="M15 37Q50 8 85 37L74 79Q51 99 26 79Z" fill="'+W+'"/><circle cx="50" cy="57" r="18" fill="'+Y+'"/><path d="M44 49L50 40 56 49 65 54 59 63 50 74 41 63 35 54Z" fill="'+P+'"/>')
put('tissue','<path d="M13 37L72 19 90 78 31 92Z" fill="'+W+'"/><path d="M17 38L39 49 57 28M39 49L31 91M40 51L79 75" stroke="#c3d1d5"/>')
put('perfume','<rect x="23" y="41" width="55" height="48" rx="8" fill="'+P+'"/><path d="M37 41V29H64V41M42 29V15H70V29M71 19H82" fill="'+Y+'"/><path d="M36 54H66V76H36Z" fill="'+W+'"/><path d="M88 16L95 12M89 24L98 28"/>')
put('butter','<ellipse cx="50" cy="77" rx="43" ry="13" fill="'+W+'"/><path d="M17 66V42L67 28 85 42V66L38 79Z" fill="'+Y+'"/><path d="M17 42L38 53 85 42M38 53V79"/>')
put('sponge','<path d="M12 35L68 19 90 37V74L34 88 12 71Z" fill="'+Y+'"/><path d="M12 35L34 52 90 37M34 52V88"/><path d="M24 38h2M44 33h2M60 43h2M73 32h2M45 66h2M73 59h2M22 60h2" stroke-width="4"/>')
put('cathedral','<path d="M15 91V35H30V13H38V35H47V58H59V35H70V13H78V35H88V91Z" fill="#c0c9c5"/><path d="M27 35V23H37M70 23H78M45 91V72Q52 57 60 72V91M23 48V61M77 48V61M15 67H88"/>')
put('fireworks','<path d="M30 66V35M30 27V10M11 44L2 35M49 44L61 32M12 66L2 77M49 66L60 79M15 53H3M45 53H60M72 40V16M70 58V86M53 47L43 34M86 46L98 33M85 62L96 75M56 63L45 76" stroke="#c79b61"/><circle cx="30" cy="53" r="5" fill="'+R+'"/><circle cx="72" cy="52" r="6" fill="'+P+'"/>')
put('skeleton','<path d="M9 48Q20 23 41 30L49 43 76 36 92 47 81 59 60 55 45 67 22 64Z" fill="#e1d6ba"/><path d="M29 41L25 61M39 42L35 64M50 45L45 61M59 43L56 54M70 41V55M22 64L17 85M46 64L53 85M62 55L74 77M12 44L5 28"/><circle cx="83" cy="45" r="3"/>')
put('diamond','<path d="M10 36L29 13H70L91 36 50 91Z" fill="#bad5df"/><path d="M10 36H91M29 13L36 36 50 91 65 36 70 13M36 36L49 13 65 36"/>')
put('lock','<rect x="20" y="40" width="62" height="49" rx="6" fill="'+Y+'"/><path d="M31 40V26Q31 9 51 9Q71 9 71 26V40" stroke-width="7"/><circle cx="51" cy="59" r="5" fill="#35546c"/><path d="M51 64V75" stroke-width="4"/>')
put('headset','<path d="M19 55V42Q19 8 50 8Q83 8 83 42V55" stroke-width="8"/><rect x="10" y="40" width="81" height="39" rx="9" fill="'+B+'"/><path d="M18 50H83V66H18Z" fill="#dce9e8"/><path d="M32 78L27 90M70 78L75 90"/>')
put('spider','<ellipse cx="50" cy="56" rx="15" ry="21" fill="#7f8e98"/><circle cx="50" cy="31" r="11" fill="#7f8e98"/><path d="M35 45L19 29 9 40M34 55L13 50 5 62M35 65L18 76 12 91M65 45L81 29 91 40M66 55L87 50 95 62M65 65L82 76 88 91M50 18V2"/>')
put('keys','<circle cx="35" cy="28" r="18" fill="'+Y+'"/><circle cx="35" cy="28" r="7" fill="'+W+'"/><path d="M35 46V89H47V80H57V69H47V46Z" fill="'+Y+'"/>')
put('microphone','<path d="M35 15Q50 1 65 15V47Q51 62 35 47Z" fill="'+B+'"/><path d="M25 37V48Q25 73 51 73Q77 73 77 48V37M51 73V91M32 92H70M37 23H63M37 33H63"/>')
put('drum','<ellipse cx="50" cy="36" rx="36" ry="16" fill="'+W+'"/><path d="M14 36V77Q50 99 86 77V36" fill="'+R+'"/><path d="M17 49L35 84 52 52 70 86 85 48M22 12L70 40M76 9L37 44" stroke="#9c8c72" stroke-width="4"/>')
put('door','<path d="M18 92V9H84V92M27 91V18H75V91Z" fill="'+Y+'"/><path d="M39 27H64V53H39Z" fill="'+W+'"/><circle cx="65" cy="69" r="3" fill="#35546c"/>')
put('stage','<path d="M6 13H94V89H6Z" fill="#e6d7bc"/><path d="M7 14H30Q34 51 14 72L29 89H7ZM93 14H70Q66 51 86 72L71 89H93Z" fill="'+R+'"/><path d="M15 78H85V90H15Z" fill="'+B+'"/>')
put('bandage','<g transform="rotate(-35 50 50)"><rect x="4" y="32" width="92" height="37" rx="16" fill="#dac6aa"/><rect x="34" y="32" width="32" height="37" rx="4" fill="'+W+'"/><path d="M16 44h1M23 55h1M76 44h1M83 55h1" stroke-width="3"/></g>')
put('rain','<path d="M16 47Q2 24 26 22Q40 1 58 20Q85 9 87 34Q104 47 83 55H19Z" fill="#b4c7cd"/><path d="M24 65L17 79M46 65L39 79M68 65L61 79M88 65L81 79M37 84L32 95M71 84L66 95" stroke="#7fa9ba"/>')
put('piano','<path d="M13 87V25H89V87M21 25Q28 7 62 10L88 25" fill="#8ca2ae"/><path d="M13 48H89V71H13Z" fill="'+W+'"/><path d="M24 49V71M35 49V71M46 49V71M57 49V71M68 49V71M79 49V71M28 48V59M40 48V59M61 48V59M73 48V59" stroke-width="3"/>')
put('storm-cloud','<path d="M15 51Q-1 29 23 25Q35 4 57 20Q84 7 89 35Q104 51 85 59H20Z" fill="#9cabb4"/><path d="M48 51L35 74H50L42 96 70 66H55L66 51Z" fill="'+Y+'"/>')
put('braces','<path d="M31 10L68 10 62 91H34Z" fill="#e5c3a6"/><path d="M24 40H76V72H24Z" fill="'+B+'"/><path d="M31 33V80M69 33V80M28 49H72M28 63H72" stroke="#6d8798" stroke-width="5"/><circle cx="50" cy="56" r="8" fill="'+W+'"/>')
put('shield','<path d="M50 7L86 23V51Q79 80 50 94Q21 80 14 51V23Z" fill="'+B+'"/><path d="M31 50L45 66 72 34" stroke="'+W+'" stroke-width="6"/>')
put('award','<path d="M30 49L17 91 41 80 51 96 63 52M52 52L68 94 81 80 93 89 76 45" fill="'+P+'"/><circle cx="51" cy="34" r="27" fill="'+Y+'"/><path d="M51 16L57 28 71 31 61 41 63 55 51 48 38 55 41 41 31 31 45 28Z" fill="'+W+'"/>')
put('recorder','<rect x="27" y="8" width="48" height="85" rx="6" fill="'+B+'"/><path d="M36 19H65V43H36Z" fill="'+W+'"/><circle cx="51" cy="61" r="9" fill="'+R+'"/><path d="M38 80H63M38 85H63"/>')
put('crops','<path d="M24 91V23M51 91V12M78 91V25" stroke="#8b9765" stroke-width="3"/><path d="M24 40L11 25M24 54L38 35M24 69L12 55M51 29L38 13M51 44L65 27M51 61L39 47M78 44L66 27M78 58L91 40M78 73L65 60" stroke="#d3b474" stroke-width="8"/>')
put('clothes','<path d="M33 12L15 25 4 49 23 57 29 43V91H75V43L81 57 97 49 86 25 67 12Q51 29 33 12Z" fill="'+B+'"/><path d="M33 12Q50 41 67 12M34 63H65M34 75H65"/>')
put('label','<path d="M12 24H66L91 50 66 78H12Z" fill="'+Y+'"/><circle cx="72" cy="50" r="4" fill="'+W+'"/><path d="M72 50Q98 8 87 5M24 39H51M24 50H55M24 61H43"/>')
put('yarn','<circle cx="34" cy="65" r="28" fill="'+P+'"/><path d="M12 52Q36 42 60 63M8 63Q32 52 59 74M13 78Q34 66 54 86M26 39Q12 69 32 92M41 39Q27 66 43 89M58 70Q74 88 83 80"/><path d="M75 84L91 24Q96 8 85 8Q77 9 81 19" stroke="#a48565" stroke-width="5"/>')
put('dishes','<ellipse cx="45" cy="69" rx="34" ry="12" fill="'+W+'"/><path d="M11 61Q45 82 79 61M11 54Q45 75 79 54M14 47Q45 66 76 47"/><path d="M66 15H87V48H66ZM87 23Q106 24 88 40" fill="'+B+'"/>')
put('ink','<path d="M26 33H73L80 85H20Z" fill="#9eafc1"/><path d="M29 24H70V36H29Z" fill="#d0d7d7"/><path d="M38 20L78 3 83 10 44 31Z" fill="'+Y+'"/><path d="M31 52H68V73H31Z" fill="'+W+'"/><path d="M41 57Q32 72 48 70Q65 75 58 58" fill="#71899b"/>')
put('stairs','<path d="M12 87H89M20 82V67H38V52H56V37H74V22H91M16 64L80 8M19 64V86M39 45V64M60 26V49M80 8V34" fill="none"/><path d="M18 90Q74 93 84 56Q90 19 51 13" stroke="'+B+'" stroke-width="6"/>')
put('leaf','<path d="M14 84Q5 21 88 8Q94 73 14 84Z" fill="'+G+'"/><path d="M12 89L73 25M35 66L31 42M49 52L74 54M59 41L58 24"/>')
put('chimney','<path d="M20 87V41H70V87Z" fill="'+R+'"/><path d="M14 31H77V44H14Z" fill="#c4a594"/><path d="M30 29Q8 11 41 8Q70 4 56 23M72 26Q90 9 77 3" fill="none" stroke="#a8b9bd" stroke-width="5"/><path d="M20 61H70M42 43V61M55 61V85"/>')
put('shell','<path d="M16 71Q1 18 56 10Q98 10 91 57Q84 95 43 85L20 93Z" fill="'+Y+'"/><path d="M24 74Q9 32 49 23Q84 17 80 51Q75 78 50 71Q29 65 39 43Q48 31 62 40Q73 54 57 58Q47 59 48 48" stroke="#b29876" stroke-width="4"/>')
put('spinning-top','<path d="M48 8H55V29M13 49Q50 12 88 49L52 90Z" fill="'+Y+'"/><path d="M13 49Q50 68 88 49M29 35L74 61"/><path d="M8 69Q-1 87 24 85M82 19Q101 25 93 40" stroke="#7f9fab"/>')
put('wheel','<circle cx="50" cy="50" r="36" fill="#aabdc2"/><circle cx="50" cy="50" r="26" fill="'+W+'"/><circle cx="50" cy="50" r="6" fill="'+B+'"/><path d="M50 24V44M50 56V76M24 50H44M56 50H76M31 31L45 45M55 55L69 69M31 69L45 55M55 45L69 31"/>')
put('coffee','<path d="M16 32H72V66Q66 86 43 86Q20 83 16 66Z" fill="'+W+'"/><path d="M72 39Q98 32 91 56Q86 68 72 62M8 89H86"/><ellipse cx="44" cy="33" rx="26" ry="7" fill="#b49371"/><path d="M35 33Q27 27 41 29Q57 33 50 35" stroke="#ece1ca"/><path d="M35 18Q28 10 35 4M54 18Q47 10 54 4" stroke="#b4c7cb"/>')
put('wine','<path d="M25 10H76L72 40Q68 62 51 63Q33 62 28 40Z" fill="#e6eef0"/><path d="M28 34H73L69 47Q50 67 31 46Z" fill="'+R+'"/><path d="M51 63V86M32 90H72"/>')
put('sand','<path d="M7 79Q32 45 52 69Q74 48 94 79Z" fill="'+Y+'"/><path d="M20 71h1M35 64h1M49 77h1M62 67h1M77 73h1M56 53h1M31 85h1M71 88h1M49 35h1M64 43h1" stroke="#ad9271" stroke-width="4"/>')
put('maze','<path d="M9 10H90V90H9V34H67V68H33V50H52M33 90V78M90 31H78V79M22 10V23H78M9 78H21V45M51 90V79H67M51 10V22" fill="none" stroke="#8ca4a7" stroke-width="6"/>')
put('plane','<path d="M48 5L59 35 95 58V67L60 55 59 78 74 88V94L50 87 26 94V88L41 78 40 55 5 67V58L41 35Z" fill="'+B+'"/>')
put('lamp','<path d="M31 13H69L84 51H16Z" fill="'+Y+'"/><path d="M50 52V85M29 89H72" stroke-width="5"/><path d="M28 58L21 65M73 58L80 65" stroke="#d8b372"/>')
put('bag','<path d="M18 36H84L90 91H12Z" fill="'+Y+'"/><path d="M33 36V23Q50 3 68 23V36M28 58H75M37 70H64"/>')
put('server','<rect x="18" y="8" width="68" height="86" rx="5" fill="#b6c6ca"/><path d="M18 35H86M18 64H86M29 23H60M29 49H60M29 79H60"/><circle cx="74" cy="23" r="3" fill="'+G+'"/><circle cx="74" cy="49" r="3" fill="'+G+'"/><circle cx="74" cy="79" r="3" fill="'+G+'"/>')
put('toothbrush','<path d="M42 91V42H57V91Q49 99 42 91Z" fill="'+B+'"/><path d="M42 42V10H74V42Z" fill="'+W+'"/><path d="M51 11V41M61 11V41M70 11V41" stroke="#a4c3c7"/>')
put('gift','<path d="M15 42H88V90H15ZM10 30H93V47H10Z" fill="'+Y+'"/><path d="M43 30H58V90H43Z" fill="'+R+'"/><path d="M50 29Q19 4 22 22Q26 37 50 29Q83 2 81 22Q76 37 50 29Z" fill="'+R+'"/>')
put('samples','<path d="M12 56H90V87H12Z" fill="'+B+'"/><path d="M20 56V31H39V56M46 56V20H64V56M72 56V36H86V56" fill="'+Y+'"/><path d="M18 31H41M44 20H66M70 36H88M32 72H73"/>')
put('tyre','<circle cx="50" cy="50" r="38" fill="#9dadaf"/><circle cx="50" cy="50" r="22" fill="'+W+'"/><path d="M15 35L24 39M28 15L35 24M55 12L54 22M80 25L72 31M89 52H79M77 80L70 72M49 89V79M22 77L29 70M37 40L63 65M63 40L37 65"/>')
put('observatory','<path d="M12 51Q12 7 51 7Q90 7 90 51V91H12Z" fill="'+B+'"/><path d="M13 51H90M49 8L49 50M58 10L71 41M29 91V69H44V91"/><path d="M51 41L84 20 91 32 58 53Z" fill="'+W+'"/>')
put('igloo','<path d="M8 84Q10 12 51 12Q91 12 94 84Z" fill="#e6eff0"/><path d="M15 59H87M26 35H77M50 13V35M32 35V59M69 35V59M25 59V84M77 59V84"/><path d="M39 84V69Q51 48 66 69V84Z" fill="#9db8c2"/>')
put('jet','<path d="M14 45L59 35 88 9 92 17 79 43 96 49 79 57 90 82 85 90 58 65 14 56Z" fill="'+B+'"/><path d="M14 50H2M23 34H8M23 69H8" stroke="#caa25e" stroke-width="4"/>')
put('cork','<path d="M30 19H69V71Q49 82 30 71Z" fill="#c5a47a"/><ellipse cx="49" cy="19" rx="20" ry="8" fill="'+Y+'"/><path d="M35 36h2M58 48h2M39 59h2M54 66h2M9 84Q23 77 36 84T63 84T94 84" stroke="#8da9af"/>')
put('bob-hair','<path d="M18 80V36Q18 7 49 7Q83 7 83 36V80H66L66 40H34V80Z" fill="#887565"/><path d="M32 30H68V57Q64 77 50 77Q35 77 32 57Z" fill="#ebc5a4"/><path d="M26 36Q46 37 51 17Q64 33 76 35" fill="#887565"/><path d="M41 48h1M59 48h1M43 63Q50 68 57 63M27 88Q50 76 74 88"/>')
put('sculpture','<path d="M28 39Q24 11 50 11Q76 11 72 39L65 61V68L86 79V91H14V79L36 68V60Z" fill="#d9dbd2"/><path d="M35 24Q55 32 65 22M40 40h3M58 40h3M50 44V53H56M42 60H59M37 68L50 80 65 68"/><path d="M17 92H85" stroke-width="4"/>')
put('police','<path d="M50 9L61 24 79 19 81 39 95 49 81 63 79 84 61 78 50 93 38 78 20 84 18 63 5 49 18 39 20 19 38 24Z" fill="'+B+'"/><path d="M50 28L56 43 72 44 60 56 64 73 50 64 35 73 39 56 27 44 44 43Z" fill="'+Y+'"/>')
put('hay','<path d="M10 44L64 24 90 43V83L37 96 10 79Z" fill="'+Y+'"/><path d="M10 44L37 61 90 43M37 61V96M25 39L52 57V92M65 25L65 48V88M17 54L28 59M44 72L54 69M66 66L79 61M17 70L29 75M49 84L60 81"/>')
put('cabin','<path d="M8 46L50 13 93 46Z" fill="#a48c71"/><path d="M17 46H84V91H17Z" fill="'+Y+'"/><path d="M17 58H84M17 72H84M43 91V60H61V91M23 48H35V60H23Z"/>')
put('envelope','<rect x="8" y="24" width="85" height="58" rx="3" fill="'+W+'"/><path d="M9 26L50 58 92 26M9 80L36 52M92 80L65 52"/>')
put('pen','<path d="M19 84L31 88 85 23 72 12Z" fill="'+B+'"/><path d="M19 84L13 96 31 88M68 17L81 29M37 71L49 81M60 27L50 18 77 3 94 18 84 32"/>')
put('question','<path d="M9 16H91V71H57L35 92V71H9Z" fill="'+W+'"/><path d="M37 34Q38 20 51 22Q72 25 60 41L50 49V55M50 64V65" stroke="#6e96a7" stroke-width="5"/>')
put('notebook','<path d="M21 10H85V92H21Z" fill="'+B+'"/><path d="M13 23H29M13 39H29M13 55H29M13 71H29M13 87H29M36 29H72M36 43H72M36 57H65M36 71H69" stroke="'+W+'" stroke-width="3"/>')
put('magnet','<path d="M17 17H38V57Q50 78 63 57V17H85V58Q79 94 50 94Q21 94 17 58Z" fill="'+R+'"/><path d="M17 17H38V37H17ZM63 17H85V37H63Z" fill="'+B+'"/><path d="M42 16Q50 10 59 16M39 5Q50 -1 62 5" stroke="#93b6c3"/>')
put('sign','<path d="M13 15H87V63H13Z" fill="'+W+'"/><path d="M49 64V96M28 30H74M28 43H63" stroke="#8ca7ae" stroke-width="4"/>')
put('car','<path d="M9 56L22 31H74L90 56V80H9Z" fill="'+B+'"/><path d="M25 37H69L79 55H17Z" fill="'+W+'"/><path d="M50 37V55M18 67H29M69 67H81"/><circle cx="24" cy="82" r="10" fill="#7b919a"/><circle cx="77" cy="82" r="10" fill="#7b919a"/>')
put('table','<path d="M8 34H93V48H8Z" fill="'+Y+'"/><path d="M20 48V93M82 48V93M20 67H82" stroke="#a88f72" stroke-width="7"/>')
put('bridge','<path d="M5 58H95V74H5Z" fill="#aebfc1"/><path d="M13 58V18M87 58V18M13 21Q50 72 87 21M29 39V58M50 49V58M73 39V58"/><path d="M6 88Q22 80 37 88T67 88T96 88" stroke="#8fb6c4"/>')
put('finish-line','<path d="M12 94V10M87 94V10M13 17H86V46H13Z" fill="'+W+'"/><path d="M14 18H29V32H14ZM44 18H59V32H44ZM72 18H86V32H72ZM29 32H44V46H29ZM59 32H73V46H59Z" fill="#648494"/><path d="M22 87H80" stroke="#b1c2c6"/>')
put('beam','<path d="M8 17H92V31H8ZM18 31V89H32V31M68 31V89H82V31M30 86L72 34 80 40 39 92Z" fill="#aabcc2"/>')
put('snake','<path d="M13 82Q1 58 32 58Q76 63 67 35Q60 12 81 15Q98 16 92 32Q82 42 79 31Q89 58 63 74Q40 84 13 82Z" fill="'+G+'"/><path d="M90 26L99 28M97 28L100 23" stroke="'+R+'"/><circle cx="83" cy="21" r="2" fill="#35546c"/>')
put('kettle','<path d="M18 53Q18 29 49 29Q78 29 77 58V82H21Z" fill="'+B+'"/><path d="M24 37Q5 4 41 6Q79 0 72 34M76 44L93 28 90 51 76 65M29 28H67M35 22H59M48 14V22"/><path d="M83 18Q76 6 84 1" stroke="#a5bcc4"/>')
put('pipe','<path d="M7 56H50V18H73V56H93V80H49Q28 80 28 58H7Z" fill="#a8bdc3"/><path d="M8 50V84M45 15H78M91 50V85M58 43H66M55 59L62 69 58 78"/>')
put('bread','<path d="M13 43Q3 21 29 20Q50 8 69 21Q96 20 88 44V88H13Z" fill="'+Y+'"/><path d="M23 45Q14 30 33 30Q50 20 65 31Q84 30 78 45V78H23Z" fill="#f2dfb6"/><path d="M33 48h2M51 40h2M65 57h2M43 66h2" stroke="#bea176" stroke-width="3"/>')
put('fly','<ellipse cx="33" cy="34" rx="18" ry="25" transform="rotate(-30 33 34)" fill="#dce7e8"/><ellipse cx="67" cy="34" rx="18" ry="25" transform="rotate(30 67 34)" fill="#dce7e8"/><ellipse cx="50" cy="61" rx="15" ry="24" fill="#829398"/><circle cx="50" cy="31" r="13" fill="#89999c"/><circle cx="42" cy="28" r="5" fill="#b48f83"/><circle cx="58" cy="28" r="5" fill="#b48f83"/><path d="M36 53L20 51 11 62M36 68L22 78 14 91M64 53L80 51 89 62M64 68L78 78 86 91"/>')
put('dab-pose','<circle cx="50" cy="20" r="16" fill="#ebc5a4"/><path d="M43 35L65 41 55 71H30Z" fill="'+B+'"/><path d="M41 43L20 28 5 21M61 43L80 32 49 17M39 71L20 94M53 71L75 88" stroke-width="6"/><path d="M40 12Q52 1 63 15" stroke="#89725d" stroke-width="5"/>')
put('stick','<path d="M12 84L82 17 91 24 21 91Z" fill="#b89a78"/><path d="M43 55L31 33 36 29 50 50M64 39L81 43 84 37 70 33" fill="#b89a78"/>')
put('dome','<path d="M9 62Q9 13 51 13Q93 13 93 62V88H9Z" fill="#b8cbd0"/><path d="M9 62H93M51 14Q25 41 27 62M51 14Q77 41 75 62M51 13V62M22 88V73H36V88M67 88V73H81V88"/>')
put('ball','<circle cx="50" cy="50" r="30" fill="#93a7ae"/><path d="M30 29Q47 24 63 37M31 76Q51 80 72 64" stroke="#d7e1e2" stroke-width="3"/>')
put('candy','<path d="M29 35L10 25 15 49 8 70 30 64M71 35L91 25 86 49 93 70 70 64" fill="'+P+'"/><path d="M29 31Q50 20 72 31V67Q50 78 29 67Z" fill="'+Y+'"/><path d="M38 29L62 70M51 26L72 58M29 43L45 72" stroke="#d1a27e" stroke-width="5"/>')
put('orange','<circle cx="47" cy="56" r="34" fill="#e4b77b"/><path d="M48 24L46 12M47 19Q59 0 77 12Q70 30 48 24" fill="'+G+'"/><path d="M29 36Q18 45 20 58" stroke="#f7dfb7" stroke-width="4"/>')
put('blanket','<path d="M14 20H86V87H14Z" fill="'+P+'"/><path d="M15 32H85M15 50H85M15 68H85M27 20V86M45 20V86M64 20V86M82 20V86" stroke="#ded6de"/><path d="M13 87V95M24 87V95M35 87V95M46 87V95M57 87V95M68 87V95M79 87V95M87 87V95"/>')
put('heart','<path d="M50 29Q30 5 15 25Q-1 49 50 90Q101 49 85 25Q70 5 50 29Z" fill="'+R+'"/><path d="M17 52H35L43 38 52 66 60 49H84" stroke="'+W+'" stroke-width="3.5"/>')
put('rope','<path d="M10 23Q38 21 43 48Q47 76 71 79Q96 81 87 55Q79 35 66 46Q54 57 69 67Q88 76 90 91" stroke="#b69b77" stroke-width="7"/><path d="M15 21L12 27M28 26L24 32M38 37L33 42M48 59L43 64M59 71L57 78M74 75L74 83" stroke="#e4d3b4" stroke-width="2"/>')
put('ditch','<path d="M4 28H28L43 71H66L81 28H97V90H4Z" fill="#cfbd9d"/><path d="M35 51H73L66 71H43Z" fill="'+B+'"/><path d="M5 28H28M81 28H97M11 28V10M18 27L24 13M85 26V10M91 26L97 15" stroke="#8b9e76"/><path d="M44 60H65" stroke="#edf4f0"/>')
for name in ['horse','dog','cat','lion','fox','deer','donkey','squirrel','animal-body']:
    put(name,animal(name))

for name, art in GLYPHS.items():
    svg='<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" fill="none" stroke="#35546c" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">'+art+'</svg>'
    ET.fromstring(svg)
    assert '<script' not in svg and 'http' not in art and '<text' not in svg, name
    GLYPHS[name]=svg
(ROOT/'src/scene-glyphs.json').write_text(json.dumps(GLYPHS,ensure_ascii=False,indent=2)+'\n')
print('Original SVG objects:',len(GLYPHS))
