import early from './scenes-lists7-9.json' with {type:'json'};
import late from './scenes-lists10-11.json' with {type:'json'};
import glyphs from './scene-glyphs.json' with {type:'json'};

export const GLYPHS=glyphs;
export const OBJECT_IDS=Object.keys(glyphs);
export const SETTINGS=['plain','indoor','water','forest','city','night','stage','desert','snow','field','mountain'] as const;
export const EFFECTS=['none','sound','quiet','motion','rotate','rise','fall','decrease','increase','focus','shake','protect','danger','refuse','agree','give','repair','scatter','many','few','alone','touch'] as const;
export type ObjectId=keyof typeof glyphs;
export type Setting=typeof SETTINGS[number];
export type Effect=typeof EFFECTS[number];
export type SentenceScene={objects:ObjectId[];setting:Setting;effect:Effect;caption:string};
export const SENTENCE_SCENES={...early,...late} as Record<string,SentenceScene[]>;
export function getSentenceScene(wordId:string,index:number):SentenceScene|null {
 return SENTENCE_SCENES[wordId]?.[index]??null;
}
