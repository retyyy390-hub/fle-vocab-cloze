import {useState} from 'react';
import type {Word} from './data';
import {WordIllustration} from './legacy-visuals';
import {GLYPHS,getSentenceScene,type ObjectId,type Setting,type Effect,type SentenceScene} from './sentence-scenes';

const glyphUrls=Object.fromEntries(Object.entries(GLYPHS).map(([id,svg])=>[id,'data:image/svg+xml;charset=utf-8,'+encodeURIComponent(svg)])) as Record<ObjectId,string>;
function ObjectImage({name,x,y,scale=1,slender=false}:{name:ObjectId;x:number;y:number;scale?:number;slender?:boolean}) {
 const href=slender?'data:image/svg+xml;charset=utf-8,'+encodeURIComponent(GLYPHS[name].replace('stroke-width="5"','stroke-width="2"')):glyphUrls[name];
 return <image href={href} x={x-50*scale} y={y-50*scale} width={100*scale} height={100*scale} preserveAspectRatio="xMidYMid meet"/>;
}
function Background({setting}:{setting:Setting}) {
 return <g stroke="#a8bcbf" strokeWidth="1.5" fill="none" opacity=".62">
  <path d="M20 168H340"/>
  {setting==='water'&&<><path d="M15 155Q32 148 49 155T83 155T117 155T151 155T185 155T219 155T253 155T287 155T321 155T355 155M15 179Q32 172 49 179T83 179T117 179T151 179T185 179T219 179T253 179T287 179T321 179T355 179" stroke="#7eaabb"/><path d="M10 143H350V197H10Z" fill="#d9e9eb" stroke="none" opacity=".65"/></>}
  {setting==='indoor'&&<><rect x="20" y="26" width="47" height="50" rx="2"/><path d="M43 26V76M20 51H67M15 168V15H346V168" stroke="#c0cbca"/></>}
  {setting==='forest'&&<><path d="M24 166V81M320 166V76" stroke="#ad9a7e" strokeWidth="4"/><path d="M24 52L5 106H43ZM320 42L299 103H343Z" fill="#cbd7be" stroke="#9fb19a"/></>}
  {setting==='city'&&<path d="M14 149V64H48V149M306 150V43H342V150M23 76H37M23 91H37M23 106H37M315 58H331M315 76H331M315 94H331M315 112H331" stroke="#b3c3c5"/>}
  {setting==='night'&&<><path d="M321 18Q296 24 310 43Q321 53 336 42Q310 46 321 18Z" fill="#dfcd9e" stroke="#c4b48b"/><path d="M35 24V33M31 28H39M281 39V47M277 43H285M64 49V57M60 53H68" stroke="#b8b9aa"/></>}
  {setting==='stage'&&<><path d="M12 13H348V171M12 13V171M12 14H51Q52 89 17 119L40 169H12ZM348 14H309Q308 89 343 119L320 169H348Z" fill="#dfbfb0" stroke="#bfaa99"/><path d="M28 171H331V179H28Z" fill="#b4c5ca"/></>}
  {setting==='desert'&&<><circle cx="319" cy="35" r="17" fill="#e9d2a0" stroke="none"/><path d="M9 168Q70 129 122 163Q215 135 351 169V196H9Z" fill="#e8d8b7" stroke="none"/></>}
  {setting==='snow'&&<><path d="M8 169Q89 149 180 169Q258 147 352 167V196H8Z" fill="#eff5f3" stroke="none"/><path d="M31 22V32M26 27H36M323 68V78M318 73H328M280 22V30M276 26H284" stroke="#a7c0c8"/></>}
  {setting==='field'&&<><path d="M10 168Q82 146 165 165Q243 144 350 168V194H10Z" fill="#dce5d2" stroke="none"/><path d="M28 171L23 158M30 171L37 157M328 171L321 156M331 171L338 159" stroke="#95ac87"/></>}
  {setting==='mountain'&&<path d="M9 167L43 89 71 131 97 113 124 167M253 167L299 74 349 167" fill="#e0e4dd" stroke="#b7c4bd"/>}
 </g>;
}
function EffectMark({kind,count}:{kind:Effect;count:number}) {
 const focusX=count===1?180:count===2?265:286;
 return <g fill="none" stroke="#6e97a7" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
  {(kind==='motion'||kind==='give')&&<path d="M145 38H215L206 30M215 38L206 46"/>}
  {kind==='rise'&&<path d="M151 47L207 18M194 18H207V32"/>}
  {kind==='fall'&&<path d="M151 18L207 47M194 47H207V33"/>}
  {kind==='rotate'&&<path d="M158 37Q174 5 207 29M196 16L207 29 192 32M208 53Q188 77 159 53M172 55L159 53 164 66"/>}
  {kind==='sound'&&<><path d="M147 47Q159 60 147 73M135 39Q156 60 135 81M211 47Q199 60 211 73M223 39Q202 60 223 81"/><path d="M173 28V19M187 28V19" stroke="#c0a577"/></>}
  {kind==='quiet'&&<><path d="M144 44Q157 59 144 74" opacity=".55"/><path d="M161 46Q172 59 161 72" opacity=".3"/><path d="M176 48Q185 59 176 70" opacity=".18"/><path d="M188 38L207 80" stroke="#b49e8a"/></>}
  {(kind==='decrease'||kind==='increase')&&<g transform={kind==='increase'?'translate(360 0) scale(-1 1)':undefined}><path d="M148 27H162V55H148Z" fill="#b4c8cc"/><path d="M172 36H186V55H172Z" fill="#c8d6d6"/><path d="M196 46H210V55H196Z" fill="#dce4df"/></g>}
  {kind==='focus'&&<><circle cx={focusX} cy="104" r="56" stroke="#c6a261" strokeDasharray="4 5"/><path d={'M'+(focusX-5)+' 36h10M'+focusX+' 31v10'} stroke="#c6a261"/></>}
  {kind==='shake'&&<path d="M133 43L143 33M132 59H143M215 43L225 33M215 59H227M176 20V9" stroke="#bb9484"/>}
  {kind==='protect'&&<path d={'M'+(focusX-62)+' 132V74Q'+focusX+' 5 '+(focusX+62)+' 74V132'} stroke="#90a994" strokeWidth="3" strokeDasharray="6 4"/>}
  {kind==='danger'&&<><path d="M180 11L199 46H161Z" fill="#ead0b1" stroke="#b99470"/><path d="M180 24V33M180 39V40" stroke="#9f7b58"/></>}
  {kind==='refuse'&&<><circle cx="180" cy="38" r="16" fill="#f4e6db" stroke="#b58b7a"/><path d="M170 27L191 49" stroke="#b58b7a"/></>}
  {kind==='agree'&&<><circle cx="180" cy="38" r="17" fill="#e3ebde" stroke="#92aa8b"/><path d="M170 38L178 46 192 29" stroke="#6d926f" strokeWidth="3"/></>}
  {kind==='repair'&&<><path d="M163 23L196 55M167 56L197 24" stroke="#9d937d" strokeWidth="5"/><circle cx="164" cy="23" r="5" fill="#d4c3a0"/></>}
  {kind==='scatter'&&[0,1,2,3,4].map(i=><circle key={i} cx={148+i*17} cy={28+(i%2)*13} r={4-i*.45} fill="#bdcbd0" stroke="none"/>)}
  {kind==='many'&&<><path d="M150 29H181V49H150ZM159 21H190V41H159ZM168 13H199V33H168Z" fill="#e5e9df" stroke="#9cae9d"/></>}
  {kind==='few'&&<><circle cx="176" cy="37" r="4" fill="#d5b777" stroke="none"/><circle cx="188" cy="40" r="3" fill="#d5b777" stroke="none"/></>}
  {kind==='alone'&&<><path d="M65 91V116M54 103H77M294 91V116M282 103H305" stroke="#d2d7ce" strokeDasharray="2 5"/></>}
  {kind==='touch'&&<><path d="M158 38L185 54M174 54H185V43"/><circle cx="194" cy="59" r="5" stroke="#c5a16f"/><path d="M205 58H214M199 47L204 40" stroke="#c5a16f"/></>}
 </g>;
}
function SlimPlant({x,y=165,scale=1}:{x:number;y?:number;scale?:number}) {
 return <g transform={'translate('+x+' '+y+') scale('+scale+')'} stroke="#8c9676" strokeWidth="2" fill="#a9bf93" strokeLinecap="round"><path d="M0 0L2-91M1-41L-18-62M1-59L20-79M-12-56L-16-76M14-73L28-79"/><ellipse cx="-18" cy="-63" rx="7" ry="3" transform="rotate(35 -18 -63)"/><ellipse cx="20" cy="-80" rx="7" ry="3" transform="rotate(-30 20 -80)"/><ellipse cx="2" cy="-93" rx="3" ry="7"/></g>;
}
function SceneObjects({wordId,index,scene}:{wordId:string;index:number;scene:SentenceScene}) {
 const objects=scene.objects,has=(name:ObjectId)=>objects.includes(name);
 if(wordId==='nov-perch') {
  if(has('bird'))return <><path d="M112 137H250" stroke="#a28b6c" strokeWidth="5" strokeLinecap="round"/>{has('tree')&&<ObjectImage name="tree" x={270} y={121} scale={1.05}/>}<ObjectImage name="bird" x={objects.filter(x=>x==='bird').length>1?153:180} y={101} scale={.8}/>{objects.filter(x=>x==='bird').length>1&&<ObjectImage name="bird" x={217} y={101} scale={.8}/>}<path d="M117 139V167M246 139V167" stroke="#a28b6c" strokeWidth="3"/></>;
  if(has('house'))return <><ObjectImage name="cliff" x={177} y={135} scale={1.28}/><ObjectImage name="house" x={160} y={73} scale={.9}/></>;
  if(has('chair'))return <><ObjectImage name="chair" x={193} y={131} scale={1.04}/><ObjectImage name="seated-person" x={171} y={105} scale={1.05}/></>;
  if(has('glass'))return <><path d="M133 144H193V168H133Z" fill="#d7c6ad" stroke="#a38d73" strokeWidth="2"/><ObjectImage name="glass" x={187} y={108} scale={.88}/></>;
 }
 if(wordId==='nov-precarious') {
  if(has('book'))return <g stroke="#66828d" strokeWidth="2.2" strokeLinejoin="round"><path d="M109 161H245"/><g transform="rotate(-11 182 150)">{[0,1,2,3].map(i=><g key={i} transform={'translate('+(i%2?9:0)+' '+(-i*19)+')'}><path d="M129 145H231V160H129Z" fill={i%2?'#d4c3a3':'#b5c9cd'}/><path d="M141 150H227M141 156H227" stroke="#f8f6ed"/></g>)}</g></g>;
  if(has('vase')||has('suitcase'))return <><path d="M105 149H196V172H105Z" fill="#d5c7b2" stroke="#a28d77" strokeWidth="2"/><g transform="rotate(13 193 139)"><ObjectImage name={has('vase')?'vase':'suitcase'} x={195} y={102} scale={1.05}/></g><path d="M239 128L247 135M237 144H249" stroke="#bc9687" strokeWidth="2"/></>;
  if(has('ladder'))return <><ObjectImage name="rock" x={219} y={155} scale={.46}/><g transform="rotate(9 180 164)"><ObjectImage name="ladder" x={180} y={104} scale={1.28}/></g></>;
  if(has('snowflake'))return <><path d="M99 143H269L253 166H90Z" fill="#bfd6dc" stroke="#87a7b2" strokeWidth="2"/><path d="M167 143L181 152 174 162M221 144L209 154 218 164" stroke="#708f9e" strokeWidth="2"/><ObjectImage name="person" x={166} y={92} scale={1.05}/></>;
 }
 if(wordId==='nov-spindly') {
  if(has('horse'))return <ObjectImage name="horse" x={180} y={110} scale={1.23} slender/>;
  if(has('chair'))return <g stroke="#8d7d65" strokeWidth="2.6" fill="#dbcba9"><path d="M136 88V39H222V88M139 57H219M138 75H220M127 90H229V101H127Z"/><path d="M137 101L132 171M153 101L157 164M207 101L203 164M220 101L228 171"/></g>;
  if(has('person'))return <g stroke="#8b947c" strokeWidth="2.2" fill="none"><ObjectImage name="book" x={293} y={85} scale={.65}/><path d="M255 121H334M164 91L207 82 271 88M174 93L214 101 268 91"/><circle cx="163" cy="67" r="14" fill="#e9c7aa"/><path d="M153 85H173L179 126H148Z" fill="#a5c0c4"/><path d="M155 126L148 170M171 126L182 170"/></g>;
  if(index===3||index===8)return <><SlimPlant x={115} scale={1.15}/><ObjectImage name="plant" x={247} y={127} scale={.95}/><ObjectImage name="sun" x={302} y={46} scale={.45}/></>;
  return <>{objects.length>1&&<ObjectImage name="plant" x={82} y={135} scale={.62}/>}<SlimPlant x={180} scale={1.2}/>{objects.length>1&&<ObjectImage name={has('rock')?'rock':'tree'} x={280} y={136} scale={.62}/>}</>;
 }
 if(wordId==='nov-glutinous') {
  if(has('shoe'))return <><ellipse cx="181" cy="151" rx="94" ry="20" fill="#c3b28d"/><ObjectImage name="shoe" x={180} y={111} scale={1.25}/><path d="M147 128Q144 145 129 151M174 136Q182 155 201 158M214 133Q223 145 236 145" stroke="#b3a279" strokeWidth="5" fill="none" strokeLinecap="round"/></>;
  const rice=has('rice');
  return <><ObjectImage name={rice?'rice':has('dough')?'dough':'meal'} x={137} y={130} scale={1.2}/>{rice?<g fill="none" stroke="#a28c69" strokeWidth="4" strokeLinecap="round"><path d="M204 33L143 107M220 40L160 112"/></g>:<ObjectImage name="hand" x={253} y={80} scale={.78}/>}<g fill="none" stroke="#cfbb8a" strokeWidth="4" strokeLinecap="round"><path d="M149 105Q157 137 188 107Q204 91 218 91M158 112Q167 136 196 115M173 101Q178 125 199 104"/></g>{has('snowflake')&&<ObjectImage name="snowflake" x={311} y={45} scale={.35}/>}</>;
 }
 if(wordId==='nov-squash') {
  if(has('bread'))return <><g transform="translate(0 104) scale(1 .33)"><ObjectImage name="bread" x={180} y={109} scale={1.25}/></g><ObjectImage name={has('box')?'box':'bag'} x={180} y={85} scale={1.13}/><path d="M115 148L101 153M244 148L258 153" stroke="#b49a76" strokeWidth="2.5"/></>;
  if(has('car'))return <><ObjectImage name="car" x={180} y={119} scale={1.6}/>{has('group')?<><ObjectImage name="group" x={154} y={87} scale={.53}/><ObjectImage name="group" x={203} y={87} scale={.53}/></>:<><ObjectImage name="suitcase" x={139} y={82} scale={.63}/><ObjectImage name="bag" x={207} y={80} scale={.58}/></>}</>;
 }
 if(wordId==='nov-muffle'&&has('clock')&&has('pillow'))return <><ObjectImage name="clock" x={172} y={119} scale={1.14}/><ObjectImage name="pillow" x={194} y={80} scale={1.14}/></>;
 const count=objects.length,positions=count===1?[180]:count===2?[94,266]:[70,180,290];
 return <>{scene.effect==='many'&&count===1?<>{[98,180,262].map((x,i)=><ObjectImage key={i} name={objects[0]} x={x} y={111+(i%2)*8} scale={.76}/>)}</>:objects.map((name,i)=><ObjectImage key={i} name={name} x={positions[i]} y={111} scale={count===1?1.21:count===2?1.03:.91}/>)}{wordId==='nov-slime'&&!has('person')&&<path d="M61 160Q105 144 137 157T211 157T296 155" stroke="#a6bd89" strokeWidth="7" fill="none" strokeLinecap="round" opacity=".8"/>}</>;
}
export function SentenceVisual({word,index}:{word:Word;index:number}) {
 const scene=getSentenceScene(word.id,index);
 if(!scene)return word.list<7?<div className="legacy-sentence-visual"><WordIllustration id={word.id}/></div>:null;
 const count=scene.objects.length;
 return <figure className="sentence-visual" data-scene-word={word.id} data-scene-index={index}>
  <svg viewBox="0 0 360 200" role="img" aria-label={scene.caption}>
   <title>{scene.caption}</title><rect x="1" y="1" width="358" height="198" rx="7" fill={scene.setting==='night'?'#e7ebec':'#f7f3e9'} stroke="#d6dfdb"/>
   <Background setting={scene.setting}/><EffectMark kind={scene.effect} count={count}/>
   <SceneObjects wordId={word.id} index={index} scene={scene}/>
  </svg><figcaption>{scene.caption}</figcaption>
 </figure>;
}
export function QuestionPicture({word,index,used,onReveal}:{word:Word;index:number;used:boolean;onReveal:()=>void}) {
 const [open,setOpen]=useState(false);
 return <div className={'question-picture'+(open?' picture-open':'')}>
  <button className="picture-toggle" type="button" aria-expanded={open} onClick={()=>{if(!open)onReveal();setOpen(!open);}}>{open?'收起情境配图':'看情境配图'}<span>{used?'已使用辅助':'辅助'}</span></button>
  {open&&<div className="question-picture-body"><SentenceVisual word={word} index={index}/><p>看图理解后，还需要另行独立作答。</p></div>}
 </div>;
}
