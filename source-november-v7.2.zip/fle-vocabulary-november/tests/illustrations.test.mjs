import test from 'node:test';
import assert from 'node:assert/strict';
import {NOVEMBER,BY_ID,EXPORT_WORDS} from '../src/data.ts';
import {SENTENCE_SCENES,OBJECT_IDS,SETTINGS,EFFECTS,getSentenceScene} from '../src/sentence-scenes.ts';
import {createRound,evaluateRound,restoreRound} from '../src/engine.ts';
import {readFile} from 'node:fs/promises';
const now=Date.parse('2026-11-07T14:00:00+08:00');

test('every November sentence has a complete, locally available context illustration',()=>{
 assert.equal(Object.keys(SENTENCE_SCENES).length,75);
 let count=0;
 for(const word of NOVEMBER){assert.equal(SENTENCE_SCENES[word.id].length,word.questions.length,word.word);
  for(let index=0;index<word.questions.length;index++){
   const scene=getSentenceScene(word.id,index);assert(scene,word.id+':'+index);assert(scene.objects.length>=1&&scene.objects.length<=3);
   for(const object of scene.objects)assert(OBJECT_IDS.includes(object),object);
   assert(SETTINGS.includes(scene.setting));assert(EFFECTS.includes(scene.effect));assert(scene.caption.length>=8,scene.caption);count++;
  }
 }
 assert.equal(count,750);
});

test('polysemous words use the depicted sense rather than one headword image for every sentence',()=>{
 assert(getSentenceScene('nov-squash',3).objects.includes('racket'));
 assert(getSentenceScene('nov-squash',4).objects.includes('orange'));
 assert(getSentenceScene('nov-squash',9).objects.includes('pumpkin'));
 assert(getSentenceScene('nov-bob',2).objects.includes('bob-hair'));
 assert.equal(getSentenceScene('nov-bob',0).setting,'water');
 assert(getSentenceScene('nov-bust',2).objects.includes('sculpture'));
 assert(getSentenceScene('nov-bust',5).objects.includes('office'));
 assert(!getSentenceScene('nov-bust',5).objects.includes('sculpture'));
 assert(getSentenceScene('nov-thump',2).objects.includes('heart'));
 assert(getSentenceScene('nov-dab',4).objects.includes('dab-pose'));
});

test('revealing a picture is saved as assistance and cannot count as independent mastery',()=>{
 const round=createRound('new',['nov-propel'],NOVEMBER,now,'november');const id=round.questionIds[0];
 round.answers[id]=id;round.formValues[id]=BY_ID.get(id).questions[round.exampleIndexes[id]].answer;round.imageHints=[id];
 const restored=restoreRound(JSON.parse(JSON.stringify(round)));assert.deepEqual(restored.imageHints,[id]);assert.equal(restored.formValues[id],round.formValues[id]);
 const result=evaluateRound(restored,{}, {},{},now);assert.equal(result.report.results[0].reason,'hint');assert.equal(result.report.results[0].correct,true);assert.equal(result.records[id].level,0);assert.equal(result.mistakes[id].reason,'hint');
});

test('pre-illustration drafts keep their answers and gain no assistance flags on upgrade',()=>{
 const round=createRound('free',['nov-bob','nov-bust'],NOVEMBER,now,'november');const id=round.questionIds[0];round.answers[id]=id;round.formValues[id]='busted';delete round.imageHints;
 const restored=restoreRound(round);assert.deepEqual(restored.imageHints,[]);assert.equal(restored.formValues[id],'busted');assert.equal(restored.position,round.position);
});

test('the Baicizhan deliverable uses comma delimiters and preserves all complete phrases',async()=>{
 const file=await readFile(new URL('../public/FLE-November-Lists-7-11.txt',import.meta.url),'utf8');assert.equal(file.trim(),EXPORT_WORDS);
 const words=file.trim().split(',');assert.equal(words.length,75);assert.equal(file.trim().includes('\n'),false);
 for(const phrase of ['eye up','gape at','hammer and tongs'])assert(words.includes(phrase));
});
